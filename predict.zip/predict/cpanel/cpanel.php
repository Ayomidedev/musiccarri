<?php 

    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>cpanel</title>



    
    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- font family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">



    <!-- mobile linking -->
    <link rel="stylesheet" href="../customizations/cpanel/mobile/header_m.css">
    <link rel="stylesheet" href="../customizations/cpanel/mobile/maincss.css">
    <link rel="stylesheet" href="../customizations/cpanel/mobile/currenygame.css">






    <link rel="stylesheet" href="../customizations/cpanel/desktop/login.css">
    <link rel="stylesheet" href="../customizations/cpanel/desktop/cpanel_user.css">
    <link rel="stylesheet" href="../customizations/cpanel/desktop/header.css">



    <script src="../functionalities/cpanel/app.js"></script>



    <div class="hidden_file" style="display:none;">
        <?php 
            require("../backend/cpanel/connection.php");
            require("../backend/cpanel/uplaod_games.php");
            require("../backend/cpanel/current_game.php");
            require("../backend/cpanel/upcoming_games.php");
            require('../backend/cpanel/logincpanel.php');
            require("../backend/cpanel/upload_america_matches.php");
            require("../backend/cpanel/upload_live_america_matches.php");
            require("../backend/cpanel/american_upcoming_games.php");
        ?>
    </div>



    <script>
        if(window.history.replaceState){
            window.history.replaceState(null, null, window.location.href);
        }
    </script>



</head>
<body>
    


    <!-- desktop views -->
    <!-- the views of Desktop view -->
    <div class="desktop_view">

        
        <div class="login_pages" style="display:<?php echo $_SESSION["cpanel_unluck"]; ?>;">
            <!-- contents -->



           <div class="mover">
               <center>
                <div class="contianer_login">   
                    <div class="title">
                    <span><i class="fa-solid fa-futbol"></i> Bestodds<span style="color:tomato;">station</span></span>
                        <p>Login Into your cpanel</p>
                    </div>

                    <div class="registrations">
                        <form action="" method="post">
                            <div class="hold_input">
                                <div class="box">
                                    <label for=""><span>cpanel username</span></label><br>
                                    <div class="content_input">
                                        <input type="text" name="login_username" id="" placeholder="cpanel usernanme" required> <i class="fa-solid fa-user"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="hold_input" style="padding-top:80px;">
                                <div class="box">
                                    <label for=""><span>cpanel password</span></label><br>
                                    <div class="content_input">
                                        <input type="text" name="login_password" id="" placeholder="cpanel password" required> <i class="fa-solid fa-user"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="button_content">
                                <button name="log_user_in">Login my account</button>
                            </div>
                        </form>
                        <div class="uodown" style="display:<?php echo $_SESSION["display_user_exist_errot"];  ?>;">
                            <div class="error">
                                <span class="user_error" style="color:red;font-weight:bold;"><?php echo $_SESSION["user_exsit_error"]; ?></span>
                            </div>
                        </div>
                    </div>


                </div>


                </center>
           </div>


            <!-- content ends here -->
        </div>





        <div class="cpanel_user">




            <div class="header_d">
                    <center><span>welcome to bestoddsstation</span></center>
            </div>
            <div class="header_tow">
                <div class="left_name">
                    <span><i class="fa-solid fa-futbol"></i> Control<span style="color:tomato;">Panel</span></span>
                </div>
                <div class="right_name">
                    <form action="" method="POST">
                        <!-- <button name="Login_user_account"><i class="fa-solid fa-user"></i> LogOut </button> -->
                </form>
                </div>
            </div>
            <div class="header_three">
                <!-- contents -->
                <div class="meuns_d">
                    <a href="#"><i class="fa-solid fa-house"></i> Home</a>
                    <a href="#"><i class="fa-solid fa-user"></i> About Us</a>
                </div>
                <div class="menus_d_right">
                    <a href="#" id="upload_football"><i class="fa-solid fa-futbol"></i>Upload Football</a>
                    <a href="#"><i class="fa-solid fa-football"></i>Upload American football</a>
                </div>
            </div>






























            
            <div class="football_views_area" id="upload_basketball" style="display:block;">
                <div class="upload_football">
                    <!-- content of football goes in here -->
                    <div class="menus_ball">
                        <button id="live_matche">upload predicted scores</button>
                        <button id="predicted_matches">upload live mathces</button>
                        <button id="upcomign_games">upload upcoming games</button>
                    </div>

                    
                    <center>
                        <h1 style="color:white;">Upload FootBall</h1>
                    </center>
                    <form action="" method="POST">
                    <div class="uploader_areas" id="live_matche_view">
                        <div class="left_upload">
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name" required>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_b_name" required>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_b_country" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                        </div>
                        <div class="right_up">
                            <div class="div_input">
                                <label for="">
                                    <span>Team A score</span><br>
                                    <select name="team_a_score" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>Team B score</span><br>
                                    <select name="team_b_score" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_a_percentage" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_b_percentage" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="center_button">
                            <button name="upload_user_games">Upload games</button>
                        </div>
                    </div>
                    </form>


                </div>



             


                <div class="predicted_games" id="predicted_games" style="display:none;">
                        <div class="left_upload" style="padding-left:400px;">
                            <form action="" method="post">
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name_c" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_b_name_c" required>  
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country_c" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_b_country_c" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                        </div>
                        <div class="right_up">
                            <div class="div_input">
                                <label for="">
                                    <span>Team A score</span><br>
                                    <select name="team_a_score_c" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>Team B score</span><br>
                                    <select name="team_b_score_c" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_a_percentage_c" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_b_percentage_c" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="center_button" style="padding-left:400px;">
                            <button name="upload_real_games">Upload games</button>
                        </div>
                    </div>
                    </form>
                </div>









                <div class="uploader_areas" id="upcoming_games" style="display:none;height:460px;padding-left:150px;">
                    <div class="left_upload">
                        <form action="" method="post">
                                <div class="div_input">
                                    <label for="">
                                        <span>Game title</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="game_title" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name_n" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_b_name_n" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country_n" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_b_country_n" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                    </div>
                    <div class="right_upload">
                         <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="For example 'Jan 15" name="team_b_month_n" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="For example '7:50'" name="team_b_time_n" required> 
                                    </label>
                        </div>
                    </div>
                    <div class="center_button" style="padding-left:400px;">
                            <button name="uplaod_upcoming_games">Upload games</button>
                    </div>
                    </form>
                </div>









            </div>















              
            <div class="football_views_area" id="upload_basketball" style="display:block;">
                <div class="upload_football">
                    <!-- content of football goes in here -->
                    <div class="menus_ball">
                        <button id="live_matche_america">upload live American FootBall matches score</button>
                        <button id="predicted_matches_america">upload predicted scores</button>
                        <button id="upcomig_america">upload upcoming games</button>
                    </div>

                    
                    <center>
                        <h1 style="color:white;">Upload America FootBall</h1>
                    </center>

                    <div class="uploader_areas" id="live_matche_view_america">
                        <div class="left_upload">
                            <form action="" method="post">
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name_p">
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_b_name_p"> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country_p" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_b_country_p" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                        </div>
                        <div class="right_up">
                            <div class="div_input">
                                <label for="">
                                    <span>Team A score</span><br>
                                    <select name="team_a_score_p" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>Team B score</span><br>
                                    <select name="team_b_score_p" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_a_percentage_p" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_b_percentage_p" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="center_button">
                            <button name="upload_live_america_Games">Upload live american games</button>
                        </div>
                        </form>
                    </div>


                </div>



                <div class="predicted_games" id="predicted_american_games" style="display:none;">
                        <div class="left_upload" style="padding-left:400px;">
                            <form action="" method="POST">
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name_a">
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_b_name_a">
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country_a" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_b_country_a" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                        </div>
                        <div class="right_up">
                            <div class="div_input">
                                <label for="">
                                    <span>Team A score</span><br>
                                    <select name="team_a_score_a" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>Team B score</span><br>
                                    <select name="team_b_score_a" id="" required>
                                        <option value="">select score</option>
                                        <option value="0">0 </option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_a_percentage_a" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                            <div class="div_input">
                                <label for="">
                                    <span>What is the percentage of team A winning over Team B</span><br>
                                    <select name="team_b_percentage_a" id="" required>
                                        <option value="">select score</option>
                                        <option value="10">10% </option>
                                        <option value="20">20%</option>
                                        <option value="30">30%</option>
                                        <option value="40">40%</option>
                                        <option value="50">50%</option>
                                        <option value="60">60%</option>
                                        <option value="70">70%</option>
                                        <option value="80">80%</option>
                                        <option value="90">90%</option>
                                        <option value="100">100%</option>
                                    </select>
                                </label>
                            </div>
                        </div>
                        <div class="center_button" style="padding-left:400px;">
                            <button name="upload_predicted_america_matched">Upload games</button>
                        </div>
                    </form>
                    </div>
                </div>



                
                <div class="uploader_areas" id="upcoming_games_america" style="display:none;height:400px;padding-left:150px;">
                    <div class="left_upload">
                        <form action="" method="post">
                                 <div class="div_input">
                                    <label for="">
                                        <span>game title</span><br>
                                        <input type="text" placeholder="Enter the a title" name="game_title_u" required > 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A name</span><br>
                                        <input type="text" placeholder="Enter the team a name" name="team_a_name_u" required > 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B name</span><br>
                                        <input type="text" placeholder="Enter the team b name" name="team_b_name_u" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team A Country</span><br>
                                        <select id="country" name="team_a_country_u" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Team B Country</span><br>
                                        <select id="country" name="team_b_country_u" required>
                                            <option>select country</option>
                                            <option value="af">Afghanistan</option>
                                            <option value="ax">Aland Islands</option>
                                            <option value="al">Albania</option>
                                            <option value="dz">Algeria</option>
                                            <option value="as">American Samoa</option>
                                            <option value="ad">Andorra</option>
                                            <option value="ao">Angola</option>
                                            <option value="ai">Anguilla</option>
                                            <option value="aq">Antarctica</option>
                                            <option value="ag">Antigua and Barbuda</option>
                                            <option value="ar">Argentina</option>
                                            <option value="am">Armenia</option>
                                            <option value="aw">Aruba</option>
                                            <option value="au">Australia</option>
                                            <option value="at">Austria</option>
                                            <option value="az">Azerbaijan</option>
                                            <option value="bs">Bahamas</option>
                                            <option value="bh">Bahrain</option>
                                            <option value="bd">Bangladesh</option>
                                            <option value="bb">Barbados</option>
                                            <option value="by">Belarus</option>
                                            <option value="be">Belgium</option>
                                            <option value="bz">Belize</option>
                                            <option value="bj">Benin</option>
                                            <option value="bm">Bermuda</option>
                                            <option value="bt">Bhutan</option>
                                            <option value="bo">Bolivia</option>
                                            <option value="bq">Bonaire, Sint Eustatius and Saba</option>
                                            <option value="ba">Bosnia and Herzegovina</option>
                                            <option value="bw">Botswana</option>
                                            <option value="bv">Bouvet Island</option>
                                            <option value="br">Brazil</option>
                                            <option value="io">British Indian Ocean Territory</option>
                                            <option value="bn">Brunei Darussalam</option>
                                            <option value="bg">Bulgaria</option>
                                            <option value="bf">Burkina Faso</option>
                                            <option value="bi">Burundi</option>
                                            <option value="kh">Cambodia</option>
                                            <option value="vm">Cameroon</option>
                                            <option value="ca">Canada</option>
                                            <option value="cv">Cape Verde</option>
                                            <option value="ky">Cayman Islands</option>
                                            <option value="cf">Central African Republic</option>
                                            <option value="td">Chad</option>
                                            <option value="cl">Chile</option>
                                            <option value="cn">China</option>
                                            <option value="cx">Christmas Island</option>
                                            <option value="cc">Cocos (Keeling) Islands</option>
                                            <option value="co">Colombia</option>
                                            <option value="km">Comoros</option>
                                            <option value="cg">Congo</option>
                                            <option value="cd">Congo, Democratic Republic of the Congo</option>
                                            <option value="ck">Cook Islands</option>
                                            <option value="cr">Costa Rica</option>
                                            <option value="ci">Cote D'Ivoire</option>
                                            <option value="hr">Croatia</option>
                                            <option value="cu">Cuba</option>
                                            <option value="cw">Curacao</option>
                                            <option value="cy">Cyprus</option>
                                            <option value="cz">Czech Republic</option>
                                            <option value="dk">Denmark</option>
                                            <option value="dj">Djibouti</option>
                                            <option value="dm">Dominica</option>
                                            <option value="do">Dominican Republic</option>
                                            <option value="ec">Ecuador</option>
                                            <option value="eg">Egypt</option>
                                            <option value="sv">El Salvador</option>
                                            <option value="gq">Equatorial Guinea</option>
                                            <option value="er">Eritrea</option>
                                            <option value="ee">Estonia</option>
                                            <option value="et">Ethiopia</option>
                                            <option value="fk">Falkland Islands (Malvinas)</option>
                                            <option value="fo">Faroe Islands</option>
                                            <option value="fj">Fiji</option>
                                            <option value="fi">Finland</option>
                                            <option value="fr">France</option>
                                            <option value="gf">French Guiana</option>
                                            <option value="pf">French Polynesia</option>
                                            <option value="tf">French Southern Territories</option>
                                            <option value="ga">Gabon</option>
                                            <option value="gm">Gambia</option>
                                            <option value="ge">Georgia</option>
                                            <option value="de">Germany</option>
                                            <option value="gh">Ghana</option>
                                            <option value="gi">Gibraltar</option>
                                            <option value="gr">Greece</option>
                                            <option value="gl">Greenland</option>
                                            <option value="gd">Grenada</option>
                                            <option value="gp">Guadeloupe</option>
                                            <option value="gu">Guam</option>
                                            <option value="gt">Guatemala</option>
                                            <option value="gg">Guernsey</option>
                                            <option value="gn">Guinea</option>
                                            <option value="gw">Guinea-Bissau</option>
                                            <option value="gy">Guyana</option>
                                            <option value="ht">Haiti</option>
                                            <option value="hm">Heard Island and Mcdonald Islands</option>
                                            <option value="va">Holy See (Vatican City State)</option>
                                            <option value="hn">Honduras</option>
                                            <option value="hk">Hong Kong</option>
                                            <option value="hu">Hungary</option>
                                            <option value="is">Iceland</option>
                                            <option value="in">India</option>
                                            <option value="id">Indonesia</option>
                                            <option value="ir">Iran, Islamic Republic of</option>
                                            <option value="iq">Iraq</option>
                                            <option value="ie">Ireland</option>
                                            <option value="im">Isle of Man</option>
                                            <option value="il">Israel</option>
                                            <option value="it">Italy</option>
                                            <option value="jm">Jamaica</option>
                                            <option value="jp">Japan</option>
                                            <option value="je">Jersey</option>
                                            <option value="jo">Jordan</option>
                                            <option value="kz">Kazakhstan</option>
                                            <option value="ke">Kenya</option>
                                            <option value="ki">Kiribati</option>
                                            <option value="kp">Korea, Democratic People's Republic of</option>
                                            <option value="kr">Korea, Republic of</option>
                                            <option value="xk">Kosovo</option>
                                            <option value="kw">Kuwait</option>
                                            <option value="kg">Kyrgyzstan</option>
                                            <option value="la">Lao People's Democratic Republic</option>
                                            <option value="lv">Latvia</option>
                                            <option value="lb">Lebanon</option>
                                            <option value="ls">Lesotho</option>
                                            <option value="lr">Liberia</option>
                                            <option value="ly">Libyan Arab Jamahiriya</option>
                                            <option value="lt">Liechtenstein</option>
                                            <option value="lt">Lithuania</option>
                                            <option value="lu">Luxembourg</option>
                                            <option value="mo">Macao</option>
                                            <option value="mk">Macedonia, the Former Yugoslav Republic of</option>
                                            <option value="mg">Madagascar</option>
                                            <option value="mw">Malawi</option>
                                            <option value="my">Malaysia</option>
                                            <option value="mv">Maldives</option>
                                            <option value="ml">Mali</option>
                                            <option value="mt">Malta</option>
                                            <option value="mh">Marshall Islands</option>
                                            <option value="mq">Martinique</option>
                                            <option value="mr">Mauritania</option>
                                            <option value="mu">Mauritius</option>
                                            <option value="yt">Mayotte</option>
                                            <option value="mx">Mexico</option>
                                            <option value="fm">Micronesia, Federated States of</option>
                                            <option value="md">Moldova, Republic of</option>
                                            <option value="mc">Monaco</option>
                                            <option value="mn">Mongolia</option>
                                            <option value="me">Montenegro</option>
                                            <option value="ms">Montserrat</option>
                                            <option value="ma">Morocco</option>
                                            <option value="mz">Mozambique</option>
                                            <option value="mm">Myanmar</option>
                                            <option value="na">Namibia</option>
                                            <option value="nr">Nauru</option>
                                            <option value="np">Nepal</option>
                                            <option value="nl">Netherlands</option>
                                            <option value="an">Netherlands Antilles</option>
                                            <option value="nc">New Caledonia</option>
                                            <option value="nz">New Zealand</option>
                                            <option value="ni">Nicaragua</option>
                                            <option value="ne">Niger</option>
                                            <option value="ng">Nigeria</option>
                                            <option value="nu">Niue</option>
                                            <option value="nf">Norfolk Island</option>
                                            <option value="mp">Northern Mariana Islands</option>
                                            <option value="no">Norway</option>
                                            <option value="om">Oman</option>
                                            <option value="pk">Pakistan</option>
                                            <option value="pw">Palau</option>
                                            <option value="ps">Palestinian Territory, Occupied</option>
                                            <option value="pa">Panama</option>
                                            <option value="pg">Papua New Guinea</option>
                                            <option value="py">Paraguay</option>
                                            <option value="pe">Peru</option>
                                            <option value="ph">Philippines</option>
                                            <option value="pn">Pitcairn</option>
                                            <option value="pl">Poland</option>
                                            <option value="pt">Portugal</option>
                                            <option value="pr">Puerto Rico</option>
                                            <option value="qa">Qatar</option>
                                            <option value="re">Reunion</option>
                                            <option value="ro">Romania</option>
                                            <option value="ru">Russian Federation</option>
                                            <option value="rw">Rwanda</option>
                                            <option value="bl">Saint Barthelemy</option>
                                            <option value="sh">Saint Helena</option>
                                            <option value="kn">Saint Kitts and Nevis</option>
                                            <option value="lc">Saint Lucia</option>
                                            <option value="mf">Saint Martin</option>
                                            <option value="pm">Saint Pierre and Miquelon</option>
                                            <option value="vc">Saint Vincent and the Grenadines</option>
                                            <option value="ws">Samoa</option>
                                            <option value="sm">San Marino</option>
                                            <option value="st">Sao Tome and Principe</option>
                                            <option value="sa">Saudi Arabia</option>
                                            <option value="sn">Senegal</option>
                                            <option value="rs">Serbia</option>
                                            <option value="cs">Serbia and Montenegro</option>
                                            <option value="sc">Seychelles</option>
                                            <option value="sl">Sierra Leone</option>
                                            <option value="sg">Singapore</option>
                                            <option value="sx">Sint Maarten</option>
                                            <option value="sk">Slovakia</option>
                                            <option value="si">Slovenia</option>
                                            <option value="sb">Solomon Islands</option>
                                            <option value="so">Somalia</option>
                                            <option value="za">South Africa</option>
                                            <option value="gs">South Georgia and the South Sandwich Islands</option>
                                            <option value="ss">South Sudan</option>
                                            <option value="es">Spain</option>
                                            <option value="lk">Sri Lanka</option>
                                            <option value="sd">Sudan</option>
                                            <option value="sr">Suriname</option>
                                            <option value="sj">Svalbard and Jan Mayen</option>
                                            <option value="sz">Swaziland</option>
                                            <option value="se">Sweden</option>
                                            <option value="ch">Switzerland</option>
                                            <option value="sy">Syrian Arab Republic</option>
                                            <option value="tw">Taiwan, Province of China</option>
                                            <option value="tj">Tajikistan</option>
                                            <option value="tz">Tanzania, United Republic of</option>
                                            <option value="th">Thailand</option>
                                            <option value="tl">Timor-Leste</option>
                                            <option value="tg">Togo</option>
                                            <option value="tk">Tokelau</option>
                                            <option value="to">Tonga</option>
                                            <option value="tt">Trinidad and Tobago</option>
                                            <option value="tn">Tunisia</option>
                                            <option value="tr">Turkey</option>
                                            <option value="tm">Turkmenistan</option>
                                            <option value="tc">Turks and Caicos Islands</option>
                                            <option value="tv">Tuvalu</option>
                                            <option value="ug">Uganda</option>
                                            <option value="ua">Ukraine</option>
                                            <option value="ae">United Arab Emirates</option>
                                            <option value="gb">United Kingdom</option>
                                            <option value="us">United States</option>
                                            <option value="um">United States Minor Outlying Islands</option>
                                            <option value="uy">Uruguay</option>
                                            <option value="uz">Uzbekistan</option>
                                            <option value="vu">Vanuatu</option>
                                            <option value="ve">Venezuela</option>
                                            <option value="vn">Viet Nam</option>
                                            <option value="vg">Virgin Islands, British</option>
                                            <option value="vi">Virgin Islands, U.s.</option>
                                            <option value="wf">Wallis and Futuna</option>
                                            <option value="eh">Western Sahara</option>
                                            <option value="ye">Yemen</option>
                                            <option value="zm">Zambia</option>
                                            <option value="zw">Zimbabwe</option>
                                        </select>
                                    </label>
                                </div>
                    </div>
                    <div class="right_upload">
                         <div class="div_input">
                                    <label for="">
                                        <span>Month</span><br>
                                        <input type="text" placeholder="For example 'Jan 15" name="team_b_month_n" required> 
                                    </label>
                                </div>
                                <div class="div_input">
                                    <label for="">
                                        <span>Time</span><br>
                                        <input type="text" placeholder="For example '7:50'" name="team_b_time_n" required> 
                                    </label>
                        </div>
                    </div>
                    <div class="center_button" style="padding-left:400px;">
                            <button name="uplaod_america_upcoming_games">Upload games</button>
                    </div>
                    </form>
                </div>







            </div>






















































































        </div>
    </div>
    <!-- end of Desktop views -->












































    <!-- mobile views -->
    <!-- the views of mobile views -->
    <div class="mobile_views">
        <!-- content mobile start-->


        <!-- content mobile ends  -->
    </div>
    <!-- end of mobile views -->


</body>
</html>


<!-- responsiveness linking -->
<link rel="stylesheet" href="../customizations/cpanel/responsiveness/res.css">