

<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,  user-scalable=0">
    <title>Subscriptions</title>


    
    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />



    <!-- mobile linking  -->
    <link rel="stylesheet" href="../customizations/dashboard/mobile/sub.css">

    <div class="this">
        <?php
            require("../backend/dashboard/connection.php");
            require("../backend/dashboard/autheticate_user.php");

            require("../backend/dashboard/subsript_check.php");

            // to distact audience
            echo "project name: superbet";
            echo "starting dates: may 15 2005";
        ?>
    </div>

</head>
<body>



    <?php 
        $username = $_SESSION["subscribe_name"];

         // select the user table
         $select_user_table = mysqli_query($connection, "SELECT * FROM $username");
         // fetch datas
         while($data = mysqli_fetch_assoc($select_user_table)){
    ?>


    <!-- desktop vies -->
    <div class="desktop_views">
        <!-- content of desktop view start here -->

        <!-- content of desktop views ends here -->
    </div>





    <!-- mobile views -->
    <div class="mobile_views">
        <!-- content of mobile view start here -->


         <!-- under the css properties of sub.css -->
        <div class="subcss" style="display:<?php echo $_SESSION["turn_on_subscription_box"];  ?>;">
            <!-- content of subscription list -->
            <div class="pusher">
                <center>
                <div class="box">


                    <!-- overbar -->
                    <center><div class="overbar"></div></center>

                    <div class="subscript_title">
                        <center>
                            <p>Subscribe to your account</p>
                            <span style="font-size:15px;">select a subscription package</span>
                        </center>
                    </div>




                    <div class="subscriptions_menus">
                        <form action="" method="POST">
                            <!-- subscription list holder -->
                            <div class="holder">
                                <div class="informations">
                                    <span>Select plans, <?php echo $data["username"]; ?></span><br>
                                    <select name="user_plan" id="" required>
                                        <option value="">select suitable plans</option>
                                        <option value="100">100$ -1year subscription</option>
                                        <option value="50">50$ -Half a year subscription</option>
                                        <option value="30">30$ -1 month subscription</option>
                                        <option value="10">10$ -1 week subscription</option>
                                    </select>
                                </div>
                                <div class="holder">
                                    <div class="informations">
                                        <span>password</span><br>
                                        <input type="password" placeholder="Re-Enter your account password ...." required name="userpasscode"><i class="fa-solid fa-lock"></i>
                                    </div>
                                </div>
                                <div class="holder">
                                    <button name="continue_processs">Proceed checkout</button>
                                </div>
                            </div>
                            <!-- subscription list holder ends here -->
                        </form>
                        <div class="logout_instead">
                            <form action="" method="POST">
                                <center><button name="logout_user">Logout</button></center>
                            </form>
                        </div>
                    </div>


                </div>
                </center>
            </div>
            <!-- end content -->
        </div>






        <div class="confirmation_box" style="display:<?php echo $_SESSION["turn_on_confirmation_box"];  ?>;">
            <!-- to tell user to confirm there order -->

            <div class="move_proceed">
                <!-- content -->
                <div class="proceed_box">

                    <!-- overbar -->
                    <center><div class="overbar"></div></center>


                    <div class="subscript_title">
                        <center>
                            <p>Checkout your order</p>
                            <span style="font-size:15px;">Click pay now to pay vise virsa</span>
                        </center>
                    </div>




                    <div class="contianer_box">
                        <!-- this box hold every details about your order -->
                        <div class="row">
                            <div class="column">
                                <div class="left"><span><i class="fa-solid fa-calendar-check"></i> Year of subscription</span></div>
                                <div class="right"><span><?php echo $_SESSION["main_year"]; ?></span></div>
                            </div>

                            <div class="column">
                                <div class="left"><span><i class="fa-solid fa-calendar-check"></i> Month of subscription</span></div>
                                <div class="right"><span><?php echo $_SESSION["main_month"]; ?></span></div>
                            </div>

                            <div class="column">
                                <div class="left"><span><i class="fa-solid fa-calendar-check"></i> Amount to pat</span></div>
                                <div class="right"><span><span><?php echo $_SESSION["amount"]; ?></span>$</span></div>
                            </div>

                            <div class="column">
                               <form action="" method="post">
                                    <button name="pay">
                                        pay now.
                                    </button>
                               </form>
                               <br>
                               <center>
                                   <form action="" method="POST">
                                       <button name="logout_user" class="logout">
                                           logout
                                       </button>
                                   </form>
                               </center>
                            </div>
                        </div>
                    </div>



                </div>
                <!-- content -->
            </div>

            <!-- confrimation box ends here -->
        </div>





        <!-- content of mobile views ends here -->
    </div>


    <?php 
        }
    ?>
    
</body>
</html>




<!-- respomsiveness Linking goes here -->
<link rel="stylesheet" href="../customizations/dashboard/responsiveness/responsiveness.css">