
<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <style>
        body{
            font-family: 'Varela Round', sans-serif;
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Dashboard manager</title>


    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- font family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">



    <!-- Desktop css linkings -->

    <!-- Desktop css linkings ends here -->



    <!-- mobile css linking -->
    <link rel="stylesheet" href="../customizations/homepage/mobile/loading_screen.css">
    <link rel="stylesheet" href="../customizations/dashboard/mobile/views_mobile.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/footer.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/drop_btn.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/american_football.css">

    <link rel="stylesheet" href="../customizations/homepage/mobile/aboutus.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/pricing_m.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/contactus.css">
    <link rel="stylesheet" href="../customizations/dashboard/mobile/header_m.css">
    <!-- mobile css linking ends here  -->



    <!-- scripts -->
    <script src="../functionalities/dashboard/app.js"></script>




    <div class="hidden_files">
        <?php
            require("../backend/dashboard/connection.php");
            require("../backend/dashboard/dashboard.php");
        ?>
    </div>


</head>
<body>



    <!-- this is the desktop views -->
    <div class="desktop_views"> 
        <!-- content of desktop start here -->

        <!-- content of mobile views ends here -->
    </div>  
    <!-- this is the desktop views ending -->







    <?php
        // getting the username
        $username = $_SESSION["current_acount_storage"];

        // select the user table
        $select_user_table = mysqli_query($connection, "SELECT * FROM $username");
        // fetch datas
        while($data = mysqli_fetch_assoc($select_user_table)){
    ?>

    <!-- this is the mobile views starting -->
    <div class="mobile_views">
        <!-- content of mobile views goes in here -->


        <!-- loading screen -->
        <div class="loading_screen" id="loading_screen" style="display:block; z-index:200">
            <script>
                window.addEventListener("load", function(){
                    document.getElementById("loading_screen").style.display = "none";
                })
            </script>
            <!-- content ends here -->
        </div>
        <!-- loading screen ends here -->







        <!-- under the css properties of header_m.css -->
        <!-- header codes goes in here -->
        <div class="header">
            <!-- content header start here -->
           <div class="layout_one">
                <div class="left_content">
                    <h2>Hi, <span style="color:lightgreen;"><?php echo $data["username"]; ?> </span></h2>
                </div>
                <div class="right_content">
                    <button id="open_drop_show"><i class="fa-solid fa-bars"></i></button>
                </div>
           </div>
           <div class="layout_two">
               <!-- content start -->
               <center>
                <a href="#" target="_SELF" class="active" id="menu_oner"><i class="fa-solid fa-house"></i> Home</a>
                <a href="#" target="_SELF" id="menu_twor"><i class="fa-solid fa-circle-check"></i> About us</a>
                <a href="#" target="_SELF" id="menu_threer" ><i class="fa-solid fa-tags"></i> pricings</a>
                <a href="#" target="_SELF" id="menu_fourr"><i class="fa-solid fa-futbol"></i> other sports</a>
               </center>
               <!-- content ends here -->
           </div>
            <!-- content header ends here -->
        </div>


        <!-- menu drop_down to display user information -->
        <div class="drop_btn" id="drop_btn" style="z-index:4000px;">
           <div class="mover">
               <div class="contents_drop">
                    <!-- content goes in here -->
                    <span>welcome, <?php  echo $data["username"]; ?> </span><br>
                    <!-- <span><?php  //echo $data["email"]; ?></span><br> -->
                    <form action="" method="POST">
                        <button name="logout_users">Logout</button>  
                    </form>
                    <!-- content ends here -->
               </div>
           </div>
        </div>

        
        <div class="drop_down_menus" id="drop_bnt">   
                <div class="drop_contents">
                    <center>
                        <a href="#" id="football">FootBall</a>
                        <a href="#" id="america_football">America FootBall</a>
                        <a href="#" id="close_bnt">close</a>
                    </center>
                </div>
        </div>







        <!-- middle_views -->
        <!-- 
            this area is the main screen that bushes the footer down down down
            it also the area that maintain the fetching of games from the database
        -->
        <!-- under the css properties of views_mobile.css -->
        <div class="fetch_vies" id="football_s">
            <!-- content of fecth views goes in here -->



            
            <!-- content of view pages -->
            <!-- under the css properties of mobile/content.css -->
            <div class="landing_page">
               <div class="contents">
                    <center>
                        <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                        <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                    </center>
               </div>
            </div>


            <!-- this area is for menus -->
            <!-- under the css properties of mobile/content.css -->
            <div class="menus">
                <!-- content goes in here-->
                <center>
                    <button class="activesers" id="butsr"><i class="fa-solid fa-list"></i> Today</button>
                    <button id="butssr"><i class="fa-solid fa-money-bills"></i> ended</button>
                    <button id="butsssr"><i class="fa-solid fa-heart"></i> Near</button>
                    <button id="butssssr"><i class="fa-solid fa-heart"></i> type</button>
                </center>
                <!-- content ends here -->
            </div>


            <div class="advertisements">
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="../asset/ads.gif" alt="">
                </div>
            </div>



            <div class="content_holder" id="today_games">
                <!-- we are creating a role that handles coloumb -->
                <!-- under the css properties of mobile/content_holder.css -->

                <div class="safe_area">
                    <!-- content start here -->
                    <div class="row">
                        <!-- to handle the columb -->


                        <?php

                            // .. selecting the games played
                            $select_games = mysqli_query($connection, "SELECT * FROM game_management_today ORDER BY rand() ");
                            while($data_two = mysqli_fetch_assoc($select_games)){
                        ?>

                            <div class="column">
                                <form action="" method="POST">
                                    <div class="layer_one">
                                        <div class="the_teams">
                                            <!-- team a -->
                                            <span style="font-size:11px; color:grey;"><?php echo $data_two["timeer"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                            <span style="font-size:10px;"><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $data_two["team_a_country"]; ?>"></span> <?php  echo $data_two["team_a_name"]; ?></span>
                                            <!-- conpetition text -->
                                            <span style="color:tomato;">vs</span>
                                            <!-- team a -->
                                            <span style="font-size:10px;"><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $data_two["team_b_country"]; ?>"></span> <?php  echo $data_two["team_b_name"]; ?></span>
                                        </div>
                                    </div>
                                    <!-- breaks -->
                            
                                    <div class="layout_four">
                                        <!-- showing if ender or started -->
                                        <input type="hidden" name="game_code" value="<?php echo $data_two["random_code"]; ?>">
                                        <div class="sign" id="blinkIcon"><span><button name="check">started</button></span></div>
                                    </div>

                                    <!-- break -->
                                    <div class="layer_three">
                                        <!-- showing time the game ended -->
                                        <span style="color:lightgreen;">fx.(<?php  echo $data_two["team_a_percentage"]; ?>)</span>
                                        <span style="color:lightgreen;">fx.(<?php  echo $data_two["team_b_percentage"]; ?>)</span>
                                    </div>
                                </form>
                            </div>


                            <cemter>
                            <div class="selected_game" id="selected_game" style="display:<?php echo $_SESSION["hide_select"]; ?>;">
                                <!-- content to show selected games -->

                                <?php 
                                    // getting user values
                                    $user_values = $_SESSION["user_select"];
                                    $select = mysqli_query($connection, "SELECT * FROM game_management_today WHERE random_code='$user_values'");
                                    while($selecter = mysqli_fetch_assoc($select)){
                                ?>
                                <center>
                                <div class="movwe">
                                    <div class="box_select">
                                        <!-- content start-->
                                        <div class="move_left">
                                            <a href="" name="subscject"><i class="fa-solid fa-rectangle-xmark" onclick="close_selecte()"></i></a>
                                        </div>



                                        <div class="team_display">
                                            <!-- team display start -->
                                            <div class="l">
                                                <center><span style="font-size:12px;"><?php  echo $selecter["team_a_percentage"]; ?>%</span></center>
                                                <div class="county"><span class="flag-icon flag-icon-<?php  echo $selecter["team_a_country"] ?>"></span>
                                                <br><center><span style="font-size:12px;"><?php  echo $selecter["team_a_name"]; ?></span></center>
                                            </div>
                                            </div>
                                            <div class="score_o">
                                                <!-- teams score-->
                                                <span id="team_a_score"><?php  echo $selecter["team_a_score"] ?></span>
                                                <!-- dash(seprator) -->
                                                <span><i class="fa-solid fa-minus"></i></span>
                                                <!-- team b score -->
                                                <span id="team_b_score"><?php  echo $selecter["team_b_scroe"] ?></span>
                                            </div>
                                            <div class="r">
                                                <center><span style="font-size:12px;"><?php  echo $selecter["team_a_percentage"] ?>%</span></center>
                                                <div class="county"><span class="flag-icon flag-icon-<?php  echo $selecter["team_b_country"] ?>"></span> 
                                                <br><center><span style="font-size:12px;"><?php  echo $selecter["team_b_name"]; ?></span></center>
                                            </div>
                                            </div>
                                            <!-- team display ends -->
                                        </div>


                                        <!-- <div class="sharebuttons">
                                            <center>
                                                <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                                                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                                            </center>
                                        </div> -->


                                        <!-- content end -->
                                    </div>
                                </div>
                                <center>
                                <?php   
                                    
                                    }
                                ?>
                            </div>
                            </cemter>



                        <?php   

                            }   
                        ?>  
                    </div>
                    <!-- content ends here -->
                </div>



            </div>

















            































            <!-- 
                this is the content holding the matches already playes
            -->


            <div class="content_holder" id="for_fiished_game_areas" style="display:none;">
                <!-- we are creating a role that handles coloumb -->
                <!-- under the css properties of mobile/content_holder.css -->

                <div class="safe_area">
                    <!-- content start here -->
                    <div class="row">
                        <!-- to handle the columb -->
                        <?php 
                            // .. we want to fetch data for real matches
                            $fecth_real_datas = mysqli_query($connection, "SELECT * FROM current_life_matchaes");
                            while($data = mysqli_fetch_assoc($fecth_real_datas)){
                        ?>
                        <div class="column">
                            <div class="layer_one">
                                <div class="the_teams">
                                    <!-- team a -->
                                    <span style="font-size:11px; color:grey;"><?php echo $data["time"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                    <span><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $data["team_a_country"]; ?> "></span> <b><?php  echo $data["team_a_name"]; ?> </b></span>
                                    <!-- conpetition text -->
                                    <span style="color:tomato;">vs</span>
                                    <!-- team a -->
                                    <span><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $data["team_b_country"]; ?> "></span> <b><?php  echo $data["team_b_name"]; ?> </b></span>
                                </div>
                            </div>
                            <!-- breaks -->
                            <div class="layer_two">
                                <!-- teams score-->
                                <!-- <span id="team_a_score"><?php // echo $data["team_a_score"]; ?> </span> -->
                                <!-- dash(seprator) -->
                                <!-- <span><i class="fa-solid fa-minus"></i></span> -->
                                <!-- team b score -->
                                <!-- <span id="team_b_score"><?php  //echo $data["team_b_scroe"]; ?></span> -->
                            </div>
                            <!-- break -->
                            <div class="layout_four">
                                <!-- showing if ender or started -->
                                <form action="" method="post">
                                <input type="hidden" name="game_code" value="<?php echo $data["random_code"]; ?>">
                                <div class="sign" id="blinkIcon"><span><button name="check" onclick="show_selection()" style="background-color:red; width:55px">closed</button></span></div>
                                </form>
                            </div>
                            <!-- break line -->
                            <div class="layer_three">
                                <!-- showing time the game ended
                                <span style="color:lightgreen">12:40 pm</span> -->
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_a_percentage"] ?>)</span>
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_b_percentage"]; ?>)</span>
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                    <!-- content ends here -->
                </div>

                

               

            </div>


























            
            <!-- this area is for near games -->
            <!-- it display games that are going to be playing next -->
            <!-- 
                it display the time the game will be played
                it display the two team that will be playing
            -->

            <!-- under the css properties of {{views_mobile.css}} -->
            <div class="near_upcoming_games" id="upcoming_matches" style="padding-top:32px;">
                <!-- the ui of the games -->
                <div class="row_near">
                    <!-- fetch game datas -->
                    <?php 
                        $fetch_near_games = mysqli_query($connection, "SELECT * FROM upcoming_games_management order by id desc");
                        while($near = mysqli_fetch_assoc($fetch_near_games)){
                    ?>
                    <div class="column_near">
                        <div class="ui_title">
                            <span><i class="fa-solid fa-baseball"></i> <?php echo $near["title"]; ?> </span>
                        </div>
                        <div class="ui_box">
                            <div class="ui_contents">
                                <div class="ui_content_one">
                                    <div class="ui_left">
                                        <div class="the_teams">
                                            <div class="team_a"><span><span class="flag-icon flag-icon-<?php echo $near["team_a_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_a_name"]; ?></span> </span></div>
                                            <div class="competitor_sign"><span><center>vs</center></span></div>
                                            <div class="team_B"><span><span class="flag-icon flag-icon-<?php echo $near["team_b_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_b_name"]; ?></span> </span></div>
                                        </div>
                                    </div>
                                    <div class="ui_right">
                                        <i class="fa-solid fa-award"></i>
                                    </div>
                                </div>


                                <div class="nn">
                                    <div class="ui_content_two">
                                        <div class="u_left">
                                            <div class="timer_S">
                                                <span style="color:green;">Time : </span>
                                                <span><?php echo $near["months"]; ?></span>
                                            </div>
                                        </div>

                                        <div class="u_right">
                                            <span><?php echo $near["timess"]; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        }
                    ?>
                </div>
            </div>







            <div class="advertisements">
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="../asset/ads.gif" alt="">
                </div>
            </div>


























            <!-- content of fetch views ends here -->
        </div>










                
                <div class="american_football" id="america_footer_view" style="display:none;">
                    
                    <!-- content of view pages -->
                    <!-- under the css properties of mobile/content.css -->
                    <!-- content of view pages -->
                    <!-- under the css properties of mobile/content.css -->
                    <div class="landing_page">
                    <div class="contents">
                            <center>
                                <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                                <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                            </center>
                    </div>
                    </div>

        
        
        
        
                    <!-- this area is for menus -->
                    <!-- under the css properties of mobile/content.css -->
                    <div class="menus_america">
                        <!-- content goes in here-->
                        <center>
                            <button class="activesers" id="butsrs" style="font-size:9px;"><i class="fa-solid fa-list"></i> Today</button>
                            <button id="butssrs" style="font-size:9px;"><i class="fa-solid fa-money-bills"></i> ended</button>
                            <button id="butsssrs" style="font-size:9px;"><i class="fa-solid fa-heart"></i> Near</button>
                            <button id="butssssrs" style="font-size:9px;"><i class="fa-solid fa-heart"></i> type</button>
                        </center>
                        <!-- content ends here -->
                    </div>
        
                    <div class="advertisements">
                        <!-- this area display plane gif advertisement -->
                        <div class="ads_content">
                            <img src="../asset/ads.gif" alt="">
                        </div>
                    </div>
        
        
        
                    <div class="content_holders">
                        <div class="safe_area" id="live_matchaed">
                            <!-- content start here -->
                            <div class="row">
                                <!-- to handle the columb -->
                                <?php 
                                    // .. we want to fetch data for real matches
                                    $fecth_real_datas = mysqli_query($connection, "SELECT * FROM predicted_american_matches order by id desc");
                                    while($datar = mysqli_fetch_assoc($fecth_real_datas)){
                                ?>
                                <div class="column">
                                   
                                    <div class="layer_one">
                                        <div class="the_teams">
                                            <!-- team a -->
                                            <span style="font-size:11px; color:grey"><?php echo $datar["timeer"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                            <span><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $datar["team_a_country"]; ?> " style="z-index:-1;"></span> <b><?php  echo $datar["team_a_name"]; ?> </b></span>
                                            <!-- conpetition text -->
                                            <span style="color:tomato;">vs</span>
                                            <!-- team a -->
                                            <span><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $datar["team_b_country"]; ?> " style="z-index:-1;"></span> <b><?php  echo $datar["team_b_name"]; ?> </b></span>
                                        </div>
                                    </div>
                                    <!-- breaks -->
                                   
                                    <!-- break -->
                                    <div class="layout_four">
                                        <!-- showing if ender or started -->
                                        <form action="" method="post">
                                        <input type="hidden" name="game_code" value="<?php echo $datar["random_code"]; ?>">
                                        <div class="sign" id="blinkIcon"><span><button  style="width:55px; background-color:red;">ended</button></span></div>
                                        </form>
                                    </div>
                                    <!-- break line -->
                                    <div class="layer_three">
                                        <!-- showing time the game ended
                                        <span style="color:lightgreen">12:40 pm</span> -->
                                        <span style="color:lightgreen;">fx.(<?php  echo $datar["team_a_percentage"]; ?>)</span>
                                        <span style="color:lightgreen;">fx.(<?php  echo $datar["team_b_percentage"]; ?>)</span>
                                    </div>
                                    <div class="layer_one" style="float:right;padding-right:7px; padding-top:16px;">
                                        (<span><?php  echo $datar["team_a_score"]; ?></span>
                                        <span>-</span>
                                        <span><?php  echo $datar["team_b_scroe"]; ?></span>)
                                    </div>
                                </div>
                                <?php 
                                    }
                                ?>
                            </div>
                            <!-- content ends here -->
                        </div>
        








                        <div class="safe_area" id="predicted_matches" style="display:none;">
                            <!-- content start here -->
                            <div class="row">
                                <!-- to handle the columb -->
                                <?php 
                                    // .. we want to fetch data for real matches
                                    $fecth_real_datas = mysqli_query($connection, "SELECT * FROM live_american_matched order by id desc");
                                    while($datar = mysqli_fetch_assoc($fecth_real_datas)){
                                ?>
                                <div class="column">
                                   
                                    <div class="layer_one">
                                        <div class="the_teams">
                                            <!-- team a -->
                                            <span style="font-size:11px; color:grey"><?php echo $datar["timeer"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                            <span><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $datar["team_a_country"]; ?> " style="z-index:-1;"></span> <b><?php  echo $datar["team_a_name"]; ?> </b></span>
                                            <!-- conpetition text -->
                                            <span style="color:tomato;">vs</span>
                                            <!-- team a -->
                                            <span><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $datar["team_b_country"]; ?> " style="z-index:-1;"></span> <b><?php  echo $datar["team_b_name"]; ?> </b></span>
                                        </div>
                                    </div>
                                    <!-- breaks -->
                                   
                                    <!-- break -->
                                    <div class="layout_four">
                                        <!-- showing if ender or started -->
                                        <form action="" method="post">
                                        <input type="hidden" name="game_code" value="<?php echo $datar["random_code"]; ?>">
                                        <div class="sign" id="blinkIcon"><span><button name="check" onclick="show_selection()" style="width:55px; background-color:red;">check</button></span></div>
                                        </form>
                                    </div>
                                    <!-- break line -->
                                    <div class="layer_three">
                                        <!-- showing time the game ended
                                        <span style="color:lightgreen">12:40 pm</span> -->
                                        <span style="color:lightgreen;">fx.(<?php  echo $datar["team_a_percentage"]; ?>)</span>
                                        <span style="color:lightgreen;">fx.(<?php  echo $datar["team_b_percentage"]; ?>)</span>
                                    </div>
                                    <div class="layer_one" style="float:right;padding-right:7px; padding-top:16px;">
                                        (<span><?php  echo $datar["team_a_score"]; ?></span>
                                        <span>-</span>
                                        <span><?php  echo $datar["team_b_scroe"]; ?></span>)
                                    </div>
                                </div>
                                <?php 
                                    }
                                ?>
                            </div>
                            <!-- content ends here -->
                        </div>
        
        
        
        
        
                        <div class="near_upcoming_games" id="upcoming_america_football" style="padding-top:20px;display:none;">
                            <!-- the ui of the games -->
                            <div class="row_near">
                                <!-- fetch game datas -->
                                <?php 
                                    $fetch_near_games = mysqli_query($connection, "SELECT * FROM upcoming_american_games_management order by id desc");
                                    while($near = mysqli_fetch_assoc($fetch_near_games)){
                                ?>
                                <div class="column_near">
                                    <div class="ui_title">
                                        <span><i class="fa-solid fa-baseball"></i> <?php echo $near["title"]; ?> </span>
                                    </div>
                                    <div class="ui_box">
                                        <div class="ui_contents">
                                            <div class="ui_content_one">
                                                <div class="ui_left">
                                                    <div class="the_teams">
                                                        <div class="team_a"><span><span class="flag-icon flag-icon-<?php echo $near["team_a_country"]; ?>" style="font-size:20px;z-index:-1;"></span> <span><?php echo $near["team_a_name"]; ?></span> </span></div>
                                                        <div class="competitor_sign"><span><center>vs</center></span></div>
                                                        <div class="team_B"><span><span class="flag-icon flag-icon-<?php echo $near["team_b_country"]; ?>" style="font-size:20px;z-index:1;"></span> <span><?php echo $near["team_b_name"]; ?></span> </span></div>
                                                    </div>
                                                </div>
                                                <div class="ui_right">
                                                    <i class="fa-solid fa-award"></i>
                                                </div>
                                            </div>
        
        
                                            <div class="nn">
                                                <div class="ui_content_two">
                                                    <div class="u_left">
                                                        <div class="timer_S">
                                                            <span style="color:green;">Time : </span>
                                                            <span><?php echo $near["months"]; ?></span>
                                                        </div>
                                                    </div>
        
                                                    <div class="u_right">
                                                        <span><?php echo $near["timess"]; ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php 
                                    }
                                ?>
                            </div>
                        </div>
        
        
        
        
        
        
                        <div class="how_to_play" style="display:none; padding-top:30px;" id="learn_america">
                            <!-- this shows a video users do...... -->
                            <div class="content_holder">
                                <!-- content ends here -->
                                <center>
                                <iframe width="370" height="200" src="https://www.youtube.com/embed/xR_Ze3uinxc" title=""I Tried To Warn You" — Elon Musk's Last WARNING & Recession Prediction (2022)" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                </center>
                                <!-- content start here -->
                            </div>
                        </div>
        
        
        
        
                    </div>
        
        
        
        
                    <div class="advertisements">
                        <!-- this area display plane gif advertisement -->
                        <div class="ads_content">
                            <img src="../asset/ads.gif" alt="">
                        </div>
                    </div>
        
        
                </div>
                        




                <!-- the footer content goes in here, -->
                <!-- footer to help user navigate easily around the screen -->
                <!-- under the css properties of footer.css -->
                <div class="safe_guard">
                    <div class="footer_mobile">
                        <!-- content goes in here -->
                        <div class="footer_title">
                            <h2>Super<span style="color:tomato;">Bet</span></h2>
                        </div>
                        <!-- menu handler -->
                        <div class="row_two">
                            <!-- column handleer -->
                        
                            <div class="wrap_a">
                                <div class="column_two">
                                    <div class="title_bar_one">
                                        <p style="color:grey; font-size:15px;">superbet.com</p>
                                        <a href="#" onclick="openabout_us()">Contact us</a>
                                        <a href="../homepage/viewer_page.php">Home</a>
                                        <a href="#" onclick="terms_of_user()">Terms of use</a>
                                    </div>
                                </div>  


                                <div class="column_two">
                                    <div class="title_bar_three">
                                        <p style="color:grey; font-size:15px;">Follow us on</p>
                                        <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                        <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                        <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                        <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                    </div>
                                </div>  
                            </div>


                            <div class="wrap_b">
                                <div class="column_two">
                                    <div class="title_bar_two">
                                        <p style="color:grey; font-size:15px;">Send Regards</p>
                                        <a href="#" id="about_us_one">About Us</a>
                                        <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                    </div>
                                </div>  

                                <div class="column_two">
                                    <div class="title_bar_four">
                                        <p style="color:grey; font-size:15px;">Download</p>
                                        <a href="#">App store</a>
                                        <a href="#">playstore</a>
                                        <a href="#">cloud store</a>
                                    </div>
                                </div>  
                            </div>



                        </div>
                        <!-- content ends here -->
                    </div>  
                </div>





                <!-- content ends here -->
        </div>











        

















        <!-- 
            about us area displays over here
            the about us area

            Under the css properties of about us........   {{ aboutus.css }}

         -->
         <div class="aboutus" style="display:none; top:92px;" id="aboutus">
            <!-- content of about us start here -->


            <style>
                .contents{
                    font-size:12px;
                }
            </style>

            <div class="aboout_content" style="padding-top:23px;">

                <div class="welcome_svg">
                    <center>
                    <img src="../asset/welcome.svg" alt="">
                    </center>
                </div>

                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="../asset/ads.gif" alt="">
                    </div>
                </div>


                <div class="contents" style="padding-top:25px;">
                    <!-- content -->
                    <h4 class="suggest">About us</h4>
                    <p>
                        welcome to super prediction site, we offer our customers the best ways of getting predicted games
                        scores. we aid to get the best out as determine to develop an AI that automatically choose who will win
                        against two teams. Thank you foe willing to spend your time with us, and willing to use our service
                    </p>
                    <!-- content ends  -->
                </div>



                <div class="contents">
                    <!-- content -->
                    <h4 class="suggest">How to play</h4>
                    <p>
                        We make the website easy and faster to let our customer understand the syntax easily, with the aid of the 
                        development we add created an to area ti view games that has already been redicted and played.. In other 
                        to check recently uploaded games, you need to create an account with our comoany, by clicking on the icon
                        at the top right corner of the header. after clicking on it, you need to then insert the following info 
                        ['username', 'gmail', 'phone number'], after that, you then varify your account. login into your account
                        a select a plan of subscription you wannt. make your payment, and they your games are ready to be viewed.
                    </p>
                    <!-- content ends  -->
                </div>


                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="../asset/ads.gif" alt="">
                    </div>
                </div>



            </div>


            <!-- the footer content goes in here, -->
            <!-- footer to help user navigate easily around the screen -->
            <!-- under the css properties of footer.css -->
            <div class="safe_guard">
                <div class="footer_mobile">
                    <!-- content goes in here -->
                    <div class="footer_title">
                        <h2>Super<span style="color:tomato;">Bet</span></h2>
                    </div>
                    <!-- menu handler -->
                    <div class="row_two">
                        <!-- column handleer -->
                    
                        <div class="wrap_a">
                            <div class="column_two">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" onclick="openabout_us()">Contact us</a>
                                    <a href="../homepage/viewer_page.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>  


                            <div class="column_two">
                                <div class="title_bar_three">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>  
                        </div>


                        <div class="wrap_b">
                            <div class="column_two">
                                <div class="title_bar_two">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_us_one">About Us</a>
                                    <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                </div>
                            </div>  

                            <div class="column_two">
                                <div class="title_bar_four">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>  
                        </div>



                    </div>
                    <!-- content ends here -->
                </div>  
            </div>



            <!-- content of about us ends here -->
         </div>






























         








        <!-- This shows the informations about pricing and payment methods -->
        <!-- under the css property of {{ pricing_m.css }} -->
        <div class="pricing_area" id="pricing_area" style="top:92px; z-index:3px;">

            <!-- content of pricing starting -->
            <div class="price_content_holder" style="padding-top:18px;">
                <!-- <div class="payment_img">
                    <center>
                        <img src="../asset/pay.svg" alt="" srcset="">
                    </center>
                </div> -->


                <div class="contents">
                    <!-- content -->
                    <h4 class="suggest">Subscribing to your account</h4>
                    <p>
                        Firstly, you need to create an account, after your account creationg verify your account with the verification
                        code sent to your email, after verification navigate back home, and login into your account again, once you are login
                        an area, to select prefered price will be poped up, select your prefer subscription plan, and insert your password to
                        clearify you are the rightfull owner of the account. AFter the steps listed. Check out your subscription and pay using 
                        any transaction cards. Thank you
                    </p>
                    <!-- content ends  -->
                </div>



                <div class="contents">
                    <!-- content -->
                    <div class="titt">
                        <h2 class="suggest">Pricing List</h2>
                    </div>


                    <div class="row_p">
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>100$</h2>
                                <span class="display"> Valid 1 year </span>
                            </center>
                        </div>
                        <!-- breaks -->
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>50$</h2>
                                <span class="display"> Valid half A year </span>
                            </center>
                        </div>

                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>30$</h2>
                                <span class="display"> Valid 1 month </span>
                            </center>
                        </div>
                        <!-- breaks -->
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>10$</h2>
                                <span class="display"> Valid 1 week </span>
                            </center>
                        </div>
                    </div>
                    <!-- content ends   -->
                </div>



                


            </div>


            <!-- the footer content goes in here, -->
            <!-- footer to help user navigate easily around the screen -->
            <!-- under the css properties of footer.css -->
            <div class="safe_guard">
                <div class="footer_mobile">
                    <!-- content goes in here -->
                    <div class="footer_title">
                        <h2>Super<span style="color:tomato;">Bet</span></h2>
                    </div>
                    <!-- menu handler -->
                    <div class="row_two">
                        <!-- column handleer -->
                    
                        <div class="wrap_a">
                            <div class="column_two">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" onclick="openabout_us()">Contact us</a>
                                    <a href="../homepage/viewer_page.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>  


                            <div class="column_two">
                                <div class="title_bar_three">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>  
                        </div>


                        <div class="wrap_b">
                            <div class="column_two">
                                <div class="title_bar_two">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_us_three">About Us</a>
                                    <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                </div>
                            </div>  

                            <div class="column_two">
                                <div class="title_bar_four">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>  
                        </div>



                    </div>
                    <!-- content ends here -->
                </div>  
            </div>





        <!-- content of pricing ends here -->

        </div>








        
        <!-- unde the css properties of contactus.css -->
        <div class="contact_us" id="contactus" onClick="close()">
            <!-- conact us content -->
            <div class="contact_mover">
                <center>
                <div class="conact_box">
                    <!-- content -->    
                    <center><p>Contact <span style="color:red;">us</span></p></center>
                    <!-- content ends here -->


                    <!-- all media links -->
                    <div class="links">
                        <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
                </center>
            </div>
            <!-- contact us content ends here -->
        </div>




       










        <!-- unde the css properties of contactus.css -->     
        <div class="terms_of_user" id="terms_of_user">
            <div class="terms_mover">
               <center>
                    <div class="content_terms">
                            <p><b>Terms of <span style="color:red;">user</span></b></p>

                            <p>
                                The website is restricted, for individuals below 18, only <span style="color:red;">18+</span> are 
                                allowed. Thank you
                            </p>

                            <button id="close_terms">ok</button>
                    </div>
               </center>
            </div>
        </div>












       <!-- feed backs -->
        <!-- unde the css properties of contactus.css -->  
        <center>
        <div class="feedbacks" id="sendfeedback">
            <div class="feedback_mover">
                <div class="feedback_content">
                        <center>
                            <p>Send Feed<span style="color:red;">backs</span></p>
                        </center>


                        <div class="regs">
                            <!-- forms -->
                            <form action="" method="post">
                               <div class="topper">
                                    <label for="">
                                        <span>your name</span><br>
                                        <input type="text" name="name" id="" placeholder="Tell us your name" required>
                                    </label>
                               </div>
                               <div class="topper">
                                    <label for="">
                                        <span>your email address</span><br>
                                        <input type="email" name="email_address" id="" placeholder="Tell us your name" required>
                                    </label>
                               </div>
                               <div class="topper">
                                    <label for="">
                                        <span>your name</span><br>
                                        <textarea name="message" id="" cols="30" rows="10" required></textarea>
                                    </label>
                               </div>
                               <div class="topper">
                                  <button name="send_feedback">send feedback</button>
                               </div>
                            </form>
                            <div class="topper">
                                  <button class="closebtn" id="closebtn">close</button>
                               </div>

                        </div>

                </div>
            </div>
        </div>
        </center>





































































       








        <!-- content mobile views ends here -->
    </div>
    <!-- this is the mobile views ending -->

    <?php 
            }
    ?>  
    
</body>
</html>




<!-- respomsiveness Linking goes here -->
<link rel="stylesheet" href="../customizations/dashboard/responsiveness/responsiveness.css">
<!-- <link rel="stylesheet" href="../customizations/responsiveness/homepage_responsiveness.css"> -->