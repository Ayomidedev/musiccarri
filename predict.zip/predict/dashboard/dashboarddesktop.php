<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="welcome to our website, we give you correct and standard betting Tips, to make you become a winner. Our AI helps predict correct match scores with 100% sure gurantee">
    <meta name="author" content="web plugs">
    <meta name="keyword" content="betting, predict, predictions, games, football, basketball, planing, money, gambling, gaming, computer, sex">

    <!-- social medias -->
    <meta property="og:site_name" content="bestoddsstation.com">
    <meta property="og:title" content="bestoddsstation">
    <meta property="descript" content="Get sure predicted betting games tips">

    <!-- imgaes -->
    <meta property="og:image" itemprop="image" content="asset/ayo.png">
    <meta property="og:type" content="image/png">
    <meta property="og:image:width" content="400">
    <meta property="og:image:height" content="400">


    <link rel="shortcut icon" href="asset/content.png" type="image/png">




    <title>predicter</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">

    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />



    <!-- desktop screen linking -->


    <!-- mobile screen linking -->
    <link rel="stylesheet" href="../customizations/homepage/mobile/loading_screen.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/header.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/content.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/content_holder.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/registrationpage.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/footer.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/aboutus.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/pricing_m.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/near_games_mobile.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/contactus.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/drop_btn.css">
    <link rel="stylesheet" href="../customizations/homepage/mobile/american_football.css">






    <!-- desktop linking -->
    <link rel="stylesheet" href="../customizations/homepage/desktop/header.css">
    <link rel="stylesheet" href="../customizations/homepage/desktop/user_render_views.css">
    <link rel="stylesheet" href="../customizations/homepage/desktop/create_account.css">
    <link rel="stylesheet" href="../customizations/homepage/desktop/dashboard_script.css">
    <link rel="stylesheet" href="../customizations/homepage/desktop/footer.css">
    <link rel="stylesheet" href="../customizations/homepage/desktop/otherdesign.css">


    <!-- script for mobile views -->
    <script src="../functionalities/homepage/viewschanger.js"></script>
    <script src="../functionalities/homepage/menus.js"></script>
    <script src="../functionalities/homepage/football.js"></script>



    <div class="hidden_files" style="display:none;">
        <!-- the php linkings -->
        <?php 
            require("../backend/homepage/connection.php");
            require("../backend/homepage/signup.php");
            require("../backend/homepage/login_user.php");
            require("../backend/homepage/render_games.php");
        ?>
    </div>


</head>
<body>



        <div class="custome_render_box">
            


        <div class="header_d">
                    <center><span>welcome to bestoddsstation</span></center>
            </div>
            <div class="header_tow">
                <div class="left_name">
                    <span><i class="fa-solid fa-futbol"></i> Bestodds<span style="color:tomato;">station</span></span>
                </div>
                <div class="right_name">
                    <form action="" method="POST">
                        <button name="create_user_account"><i class="fa-solid fa-circle-plus"></i> create account</button>
                        <button name="Login_user_account"><i class="fa-solid fa-user"></i> Login account</button>
                </form>
                </div>
            </div>
            <div class="header_three">
                <!-- contents -->
                <div class="meuns_d">
                    <a href="#"><i class="fa-solid fa-house"></i> Home</a>
                    <a href="#" id="about_d_us"><i class="fa-solid fa-user"></i> About Us</a>
                    <a href="#" id="pricing_one"><i class="fa-solid fa-tags"></i> Pricing</a>
                    <a href="#" id="learn_hot_to"><i class="fa-solid fa-school"></i>How to predict</a>
                    <a href="#"><i class="fa-solid fa-id-badge"></i> Contact us</a>
                </div>
                <div class="menus_d_right">
                    <a href="#" id="Tab1"><i class="fa-solid fa-futbol"></i>Football</a>
                    <a href="#" id="Tab2"><i class="fa-solid fa-football"></i> American football</a>
                    <a href="#">Others</a>
                </div>
            </div>
    


        <!-- under /desktop/dashboard_script.css -->
        <?php 
            $login_username = $_SESSION["user_untachible_token"];
            $select_from_user = mysqli_query($connect_db, "SELECT * FROM $login_username");
            while($data_fetch = mysqli_fetch_assoc($select_from_user)){
        ?>
        <div class="custome_render_box">
            <!-- this is the dash board area. this is where the dash board script are stored -->
            <div class="header_d">
                    <center><span>welcome to bestoddsstation</span></center>
            </div>
            <div class="header_tow">
                <div class="left_name">
                    <span><i class="fa-solid fa-futbol"></i> welcome <span style="color:tomato;"><?php echo $data_fetch["username"]; ?></span></span>
                </div>
                <div class="right_name">
                    <form action="" method="POST">
                        <button name="logout"><i class="fa-solid fa-user"></i> Logout</button>
                    </form>
                </div>
            </div>
            <div class="header_three">
                <!-- contents -->
                <div class="meuns_d">
                    <a href=""><i class="fa-solid fa-house"></i> Home</a>
                    <a href="#" id="about_d_two"><i class="fa-solid fa-user"></i> About Us</a>
                    <a href="#" id="pricing_two"><i class="fa-solid fa-tags"></i> Pricing</a>
                    <a href="#" id="learn_hot_to_2"><i class="fa-solid fa-school"></i>How to predict</a>
                    <a href="#"><i class="fa-solid fa-id-badge"></i> Contact us</a>
                </div>
                <div class="menus_d_right">
                    <a href="#" id="Tab3"><i class="fa-solid fa-futbol"></i>Football</a>
                    <a href="#" id="Tab4"><i class="fa-solid fa-football"></i> American football</a>
                    <a href="#">Others</a>
                </div>
            </div>


            




                <div class="games_hodler" id="fooball_views_da">
                    <!-- content of user render views is here -->


                    <div class="center_content_landing_page">
                        <!-- content -->
                        <center>
                            <div class="center_content">
                                <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                                <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                            </div>
                        </center>
                    </div>







                    <div class="drop_down_matches" style="padding-left:320px;">
                        <!-- this area display the life matched --> 

                        <div class="titl" id="predicted_title_am">
                            <span>Fixed Football predicted scores</span>
                        </div>
                        <div class="titlr" id="live_match_titles">
                            <span>Live match scores</span>
                        </div>
                        <div class="titlr" id="upcomign_ball_5">
                            <span>upcomig Football matchaes</span>
                        </div>
                        <div class="mob">
                            <div class="meuns_f">
                                <a href="#" id="live_button_4"><i class="fa-solid fa-house"></i> predicted score</a>
                                <a href="#" id="upcoming_button_4"><i class="fa-solid fa-user"></i> Match live score</a>
                                <a href="#" id="predict_Desktop_4"><i class="fa-solid fa-tags"></i>  Upcoming America Football Matched</a>
                            </div>
                        </div>

                        <div class="row_d" id="predicted_match_4">
                            <?php 
                                // .. we want to fetch data for real matches
                                $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM game_management_today order by id desc");
                                while($data = mysqli_fetch_assoc($fecth_real_datas)){
                            ?>
                            <div class="column_d">
                                <div class="team_handle">
                                <span>
                                    <!-- time management -->
                                    <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["timeer"]; ?></span><br><br>
                                    <!-- time management ends here -->
                                    <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_a_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_a_name"]; ?></b></span></span>
                                    <span style="color:red;"><b>vs</b></span>
                                    <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_b_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_b_name"]; ?></b></span></span>
                                </span>
                                </div>
                                <div class="score_handle">
                                    <!-- <p>welcome2</p> -->
                                <span><b>click to get match details</b></span>
                                </div>
                                <div class="button_handle">
                                    <button>preview game</button>
                                </div>
                                <div class="percentage_handle">
                                    <!-- <p>welcome4</p> -->
                                    <!-- <p>welcome2</p> -->
                                    (<span id="team_a_score"><?php echo $data["team_a_percentage"]; ?>%</span>
                                    <span><i class="fa-solid fa-minus"></i></span>
                                    <span id="team_b_score"><?php echo $data["team_b_percentage"]; ?>%</span>)
                                </div>
                            </div>
                            <?php 
                                }
                            ?>
                        </div>




                        <div class="row_d" id="live_matached_4" style="display:none;">
                            <?php 
                                // .. we want to fetch data for real matches
                                $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM live_american_matched order by id desc");
                                while($data = mysqli_fetch_assoc($fecth_real_datas)){
                            ?>
                            <div class="column_d">
                                <div class="team_handle">
                                <span>
                                    <!-- time management -->
                                    <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["timeer"]; ?></span><br><br>
                                    <!-- time management ends here -->
                                    <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_a_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_a_name"]; ?></b></span></span>
                                    <span style="color:red;"><b>vs</b></span>
                                    <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_b_country"];  ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_b_name"]; ?></b></span></span>
                                </span>
                                </div>
                                <div class="score_handle">
                                    <!-- <p>welcome2</p> -->
                                <span><b>click to get match details</b></span>
                                </div>
                                <div class="button_handle">
                                    <button>preview game</button>
                                </div>
                                <div class="percentage_handle">
                                    <!-- <p>welcome4</p> -->
                                    <!-- <p>welcome2</p> -->
                                    (<span id="team_a_score"><?php echo $data["team_a_percentage"] ?>%</span>
                                    <span><i class="fa-solid fa-minus"></i></span>
                                    <span id="team_b_score"><?php echo $data["team_b_percentage"]; ?>20%</span>)
                                </div>
                            </div>
                            <?php 
                                }
                            ?>
                        </div>









                        <!-- upcoming games -->
                        <div class="row_up" id="upcoming_american_games_5">
                            <?php 
                                $select_upcoming_bbb = mysqli_query($connect_db, "SELECT * FROM upcoming_games_management order by id desc");
                                while($dt = mysqli_fetch_assoc($select_upcoming_bbb)){
                            ?>
                            <div class="columnb_coming">
                                <div class="main_side_one">
                                <div class="left_i"> <span style="color:grey; font-size:10px;"><?php echo $dt["title"]; ?></span><br></div>
                                <div class="right_i"><span>Time: <span><?php echo $dt["months"]; ?></span>,<span><?php echo $dt["timess"]; ?></span></span></div>

                                <div class="teams_coming_up">
                                    <div class="team_l"><center><span><span class="flag-icon flag-icon-<?php echo $dt["team_a_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $dt["team_a_name"]; ?></span></span></center></div>
                                    <div class="center_o"><span id="conpetitorsign">Vs</span></div>
                                    <div class="team_r"><center><span><span class="flag-icon flag-icon-<?php echo $dt["team_b_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $dt["team_b_name"]; ?></span></span></center></div>
                                </div>
                                </div>
                            </div>
                            <?php 
                                }
                            ?>
                        </div>
                        
                        <!-- this area ends the life matched -->
                    </div>


                    <!-- ends here -->
                </div>










                <!-- display the america football matches -->
                <div class="games_hodler" id="america_football_da" style="display:none;">
                    <!-- content of user render views is here -->


                    <div class="center_content_landing_page">
                        <!-- content -->
                        <center>
                            <div class="center_content">
                                <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                                <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                            </div>
                        </center>
                    </div>







                    <div class="drop_down_matches" style="padding-left:320px;">
                        <!-- this area display the life matched --> 

                        <div class="titl" id="predicted_title">
                            <span>Fixed America FootBall predicted scores</span>
                        </div>
                        <div class="titlr" id="live_match_title">
                            <span>Live American match scores</span>
                        </div>
                        <div class="titlr" id="upcomign_ball_4">
                            <span>upcomig America matchaes</span>
                        </div>
                        <div class="mob">
                            <div class="meuns_f">
                                <a href="#" id="live_button_3"><i class="fa-solid fa-house"></i> predicted score</a>
                                <a href="#" id="upcoming_button_3"><i class="fa-solid fa-user"></i> Match live score</a>
                                <a href="#" id="predict_Desktop_3"><i class="fa-solid fa-tags"></i>  Upcoming America Football Matched</a>
                            </div>
                        </div>

                        <div class="row_d" id="predicted_match_3">
                            <?php 
                                // .. we want to fetch data for real matches
                                $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM current_life_matchaes order by id desc");
                                while($data = mysqli_fetch_assoc($fecth_real_datas)){
                            ?>
                            <div class="column_d">
                                <div class="team_handle">
                                <span>
                                    <!-- time management -->
                                    <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["time"]; ?></span><br><br>
                                    <!-- time management ends here -->
                                    <span id="country_a"><span class="flag-icon flag-icon-ng" style="z-index:-1;"></span> <span id="team_a_name"><b>Nigeria</b></span></span>
                                    <span><b>vs</b></span>
                                    <span id="country_a"><span class="flag-icon flag-icon-ne" style="z-index:-1;"></span> <span id="team_a_name"><b>United Emirates</b></span></span>
                                </span>
                                </div>
                                <div class="score_handle">
                                    <!-- <p>welcome2</p> -->
                                <span><b>click to get match details</b></span>
                                </div>
                                <div class="button_handle">
                                    <button>preview game</button>
                                </div>
                                <div class="percentage_handle">
                                    <!-- <p>welcome4</p> -->
                                    <!-- <p>welcome2</p> -->
                                    (<span id="team_a_score">80%</span>
                                    <span><i class="fa-solid fa-minus"></i></span>
                                    <span id="team_b_score">20%</span>)
                                </div>
                            </div>
                            <?php 
                                }
                            ?>
                        </div>




                        <div class="row_d" id="live_matached_3" style="display:none;">
                            <?php 
                                // .. we want to fetch data for real matches
                                $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM current_life_matchaes order by id desc");
                                while($data = mysqli_fetch_assoc($fecth_real_datas)){
                            ?>
                            <div class="column_d">
                                <div class="team_handle">
                                <span>
                                    <!-- time management -->
                                    <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["time"]; ?></span><br><br>
                                    <!-- time management ends here -->
                                    <span id="country_a"><span class="flag-icon flag-icon-ng" style="z-index:-1;"></span> <span id="team_a_name"><b>Nigeria</b></span></span>
                                    <span><b>vs</b></span>
                                    <span id="country_a"><span class="flag-icon flag-icon-ne" style="z-index:-1;"></span> <span id="team_a_name"><b>United Emirates</b></span></span>
                                </span>
                                </div>
                                <div class="score_handle">
                                    <!-- <p>welcome2</p> -->
                                <span><b>click to get match details</b></span>
                                </div>
                                <div class="button_handle">
                                    <button>preview game</button>
                                </div>
                                <div class="percentage_handle">
                                    <!-- <p>welcome4</p> -->
                                    <!-- <p>welcome2</p> -->
                                    (<span id="team_a_score">80%</span>
                                    <span><i class="fa-solid fa-minus"></i></span>
                                    <span id="team_b_score">20%</span>)
                                </div>
                            </div>
                            <?php 
                                }
                            ?>
                        </div>









                        <!-- upcoming games -->
                        <div class="row_up" id="upcoming_american_games_4">
                            <div class="columnb_coming">
                                <div class="main_side_one">
                                <div class="left_i"> <span style="color:grey; font-size:10px;">Champion Leagues</span><br></div>
                                <div class="right_i"><span>Time: <span>Jan 40</span>,<span>6:50pm</span></span></div>

                                <div class="teams_coming_up">
                                    <div class="team_l"><center><span><span class="flag-icon flag-icon-ng" style="z-index:-1;"></span> <br><span class="team_name_bn">Nigeria</span></span></center></div>
                                    <div class="center_o"><span id="conpetitorsign">Vs</span></div>
                                    <div class="team_r"><center><span><span class="flag-icon flag-icon-ng" style="z-index:-1;"></span> <br><span class="team_name_bn">Nigeria</span></span></center></div>
                                </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- this area ends the life matched -->
                    </div>


                    <!-- ends here -->
                </div>

















            <div class="safe_guards" style="z-index:30px">
                <div class="footer">
                    <!-- content of footer goes in here -->
                    <div class="footer_content">
                        <div class="title">
                            <span><i class="fa-solid fa-futbol"></i> Bestodds<span style="color:tomato;">station</span></span>
                        </div>

                        <center>
                        <div class="mover">
                            <div class="left_footer_content">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" id="contact_bb_2"">Contact us</a>
                                    <a href="../index.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_2">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_3">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_5_three">About Us</a>
                                    <a href="#"  id="send_feedback_D_2">FeedBacks</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_4">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>
                        </div>
                        </center>
                    </div>
                    <!-- content ends here -->
                </div>  
            </div>

        </div>





                    
            





        <?php 
            }
        ?>


        </div>






    
</body>
</html>