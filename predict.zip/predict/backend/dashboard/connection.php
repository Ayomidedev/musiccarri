<?php 

$host = "localhost";
$user = "root";
$password = "";
$database = "superbet";


// connecting to thr database
$connection = mysqli_connect(
    $host,
    $user,
    $password,
    $database
);

// checking if it connected
if($connection){
    // echo "<script>alert('connected');</script>";
}else{
    echo "<script>alert('error trying to connect');</script>";
}
   
   

?>