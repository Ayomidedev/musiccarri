<?php 
 

    session_start();





  
    // redirect user back, if the session for user is not set
    if(!isset($_SESSION["current_acount_storage"])){
        header("Location: ../");
    }


    $_SESSION["hide_select"] = "none";

    // selected game
    if(isset($_POST["check"])){
        $_SESSION["user_select"] = $_POST["game_code"];
        if(isset($_SESSION["user_select"])){
            $_SESSION["hide_select"] = "block";
        }else{
            $_SESSION["hide_select"] = "none";
        }
        // 
    }


    // logout button
    if(isset($_POST["logout_users"])){
        session_destroy();
        header("Location: ../");
    }







       // sending feedbacks
       if(isset($_POST["send_feedback"])){

        $name = $_POST["name"];
        $email_address = $_POST["email_address"];
        $user_message = $_POST["message"];


        // seending mail
        $to =  "quadriaremu6@gmail.com";
        $from = $email_address;
        $message = "
            ".$email_address." with the name ".$name." send a feedback \n\n\n
            feedback: \n\n ".$user_message."
        ";  

        $mail_ = mail($to, $from, $message);
        if($mail_){
            echo "<script>alert('Thank you, your feedback has been sent');</script>";
        }else{
            echo "<script>alert('couldnt send feedback, sorry');</script>";
        }
    }



?>