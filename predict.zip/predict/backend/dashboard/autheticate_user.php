<?php 



    // adding connection module
    require("connection.php");



    if(isset($_POST["logout_user"])){
        session_destroy();
        header("Location: ../index.php");
    }



    $_SESSION["turn_on_confirmation_box"] = "none";
    $_SESSION["turn_on_subscription_box"] = "block";



    // redirect user back, if the session for user is not set
    if(!isset($_SESSION["subscribe_name"])){
        header("Location: ../index.php");
    }


    // checking password

    // .. getting user variables
    $username = $_SESSION["subscribe_name"];
    $userpasscode = $_POST["userpasscode"];
    $user_plan = $_POST["user_plan"];


    if(isset($_POST["continue_processs"])){
        // .. we  want to check if passowrd is correct
        $select_user = mysqli_query($connection, "SELECT * FROM $username WHERE passcode='$userpasscode'");
        if($select_user){
            // .. naw check if password is correct
            $check_passcode = mysqli_num_rows($select_user);
            if($check_passcode > 0){
                 // ... we need to set session to display of the sub box, and open the confirmation bos
                $_SESSION["turn_on_subscription_box"] = "none";
                $_SESSION["turn_on_confirmation_box"] = "block";
            }else{
                echo "<script>alert('Insert the correct password to account, ".$username."');</script>";
            }
        }else{
            echo "<script>alert('cant not select user');</script>";
        }
    }


























 



?>