<?php 







    // requiring connection module
    require("connection.php");


    //.. get all variables
    $title_u = $_POST["game_title_u"];
    $team_a_name_u = $_POST["team_a_name_u"];
    $team_b_name_u = $_POST["team_b_name_u"];
    $team_a_country_u = $_POST["team_a_country_u"];
    $team_b_country_u = $_POST["team_b_country_u"];
    $month = $_POST["team_b_month_n"];
    $time = $_POST["team_b_time_n"];









    // .. create a database to manage user game
    $Tb_name = "game_management_today";
    $create_table = mysqli_query($connection, "CREATE TABLE upcoming_american_games_management(
        id INT(100) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(100),
        team_a_name VARCHAR(100),
        team_b_name VARCHAR(100),
        team_a_country VARCHAR(100),
        team_b_country VARCHAR(100),
        months VARCHAR(100),
        timess VARCHAR(100)
    )");
    if($create_table){
        // .. if the table is created, do nothin
        echo "<script>alert('created');</script>";
    }else{
        // echo "<script>alert('could not created game table');</script>";
    }




    if(isset($_POST["uplaod_america_upcoming_games"])){
        // ... insert user data
          $insert_data = "INSERT INTO upcoming_american_games_management(
            id, title, team_a_name, team_b_name, team_a_country, team_b_country,
            months, timess
        ) VALUES (
            '', '$title_u', '$team_a_name_u', '$team_b_name_u', '$team_a_country_u', '$team_b_country_u', '$month',
            '$time'
        )";

        if($connection->query($insert_data) === TRUE){
            echo "<script>alert('The game has been inserted successfully');</script>";
        }else{
            echo "<script>alert('There was an arror while trying to insert data into game table');</script>";
        }
    }

?>