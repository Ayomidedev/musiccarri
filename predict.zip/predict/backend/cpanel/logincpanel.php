<?php 
 

session_start();


if(isset($_SESSION["stay"])){
    $_SESSION["cpanel_unluck"] = "block";
}else{
    $_SESSION["cpanel_unluck"] = "none";
}
 
$_SESSION["display_user_exist_errot"] = "none";

$_SESSION["cpanel_unluck"] = "block";

//   cpanel logins are
$cpanel_user_name = "bestoddsstation_panel_cpanelmanager";
$cpanel_user_pass = "bestoddsstation_admin";

//.. user values
$username = $_POST["login_username"];
$password = $_POST["login_password"];


if(isset($_POST["log_user_in"])){

    // check if user name is correct
    if($username === $cpanel_user_name){

        if($password === $cpanel_user_pass){

            $_SESSION["cpanel_unluck"] = "none";
            $_SESSION["stay"] = "stay";

        }else{
            $_SESSION["display_user_exist_errot"] = "block";
            $_SESSION["user_exsit_error"] = "The password is wrong !";  
        }

    }else{
        $_SESSION["display_user_exist_errot"] = "block";
        $_SESSION["user_exsit_error"] = "The username is wrong !";
    }
}




if(isset($_POST["Login_user_account"])){
    // session_destroy();
}


?> 