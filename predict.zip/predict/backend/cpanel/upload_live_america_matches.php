<?php 


    session_start();

    // requiring connection module
    require("connection.php");


    //.. get all variables
    $team_a_name_p = $_POST["team_a_name_p"];
    $team_b_name_p = $_POST["team_b_name_p"];
    $team_a_country_p = $_POST["team_a_country_p"];
    $team_b_country_p = $_POST["team_b_country_p"];
    $team_a_score_p = $_POST["team_a_score_p"];
    $team_b_score_p = $_POST["team_b_score_p"];
    $team_a_percentage_p = $_POST["team_a_percentage_p"];
    $team_b_percentage_p = $_POST["team_b_percentage_p"];








    // .. random number
    $random = rand();





    // .. create a database to manage user game
    $Tb_name = "game_management_today";
    $create_table = mysqli_query($connection, "CREATE TABLE live_american_matched(
        id INT(100) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        timeer VARCHAR(100),
        team_a_name VARCHAR(100),
        team_b_name VARCHAR(100),
        team_a_country VARCHAR(100),
        team_b_country VARCHAR(100),
        team_a_score INT(100),
        team_b_scroe INT(100),
        team_a_percentage INT(100),
        team_b_percentage INT(100),
        random_code INT(100)
    )");
    if($create_table){
        // .. if the table is created, do nothin
        echo "<script>alert('created');</script>";
    }else{
        // echo "<script>alert('could not created game table');</script>";
        // echo "<script>alert('was not created');</script>";
    }


    $date = date("h:i:sa y");
    $_SESSION["store_year"] = $date;
    $main_dates = $_SESSION["store_year"];




    // ... we want to insert game datas into the table
    if(isset($_POST["upload_live_america_Games"])){
        // ... insert user data
        $insert_data = "INSERT INTO live_american_matched(
            id, timeer, team_a_name, team_b_name, team_a_country, team_b_country, team_a_score, team_b_scroe,
            team_a_percentage, team_b_percentage, random_code
        ) VALUES (
            '', '$main_dates', '$team_a_name_p', '$team_b_name_p', '$team_a_country_p', '$team_b_country_p', '$team_a_score_P',
            '$team_b_score_p', '$team_a_percentage_p', '$team_b_percentage_p', '$random'
        )";
        if($connection->query($insert_data) === TRUE){
            echo "<script>alert('The game has been inserted successfully');</script>";
        }else{
            echo "<script>alert('There was an arror while trying to insert data into game table');</script>";
        }
    }
?>