<?php 
 

 require("connection.php");


    if(!isset($_SESSION["subscribe_name"])){
        header("Location: index.php");
    }


    // getting values
    $username = $_SESSION["subscribe_name"];
    $price = $_SESSION["price"];
    $sub_type = $_SESSION["sub_type"];

    // date
    $time = date('y-m-d');
    $_SESSION["time"] = $time;
    $date = $_SESSION["time"];

    $valid_tile = $_SESSION["main_month"];


    //  ,,, connection area
    // we want to create history table
    $create_history_table = mysqli_query($connect_db, "CREATE TABLE history_history_manager(
        id INT(100) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100),
        amount INT(100),
        subscription_type VARCHAR(100),
        time VARCHAR(100),
        valid_till VARCHAR(100)
    )");
    if($create_history_table){
        //echo "<script>alert('inserted');</script>";
    }else{
        //echo "<script>alert('not created');</script>";
    }


    if(isset($_POST["end_progress"])){
        // .. we want to insert datas
        $insert_history = "INSERT INTO history_history_manager(id, username, amount, subscription_type,
        time, valid_till) VALUES (
            '', '$username', '$price', '$sub_type', '$date', '$valid_tile'
        )";
        if($connect_db->query($insert_history) === TRUE){
            echo "<script>alert('Thanks for subscribing to your account');</script>";
            header("Location: index.php");
            unset($_SESSION["subscribe_name"]);
            $_SESSION["user_login_box"] = "block";
        }else{
            echo "<script>alert('cant subscrib users');</script>";
        }
        
    }


?>