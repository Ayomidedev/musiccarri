<?php 

    session_start();
    ob_start();



    $_SESSION["hide_select"] = "none";

    // selected game
    if(isset($_POST["check"])){
        $_SESSION["user_select"] = $_POST["game_code"];
        if(isset($_SESSION["user_select"])){
            $_SESSION["hide_select"] = "block";
        }else{
            $_SESSION["hide_select"] = "none";
        }
        // 
    }


?>