<?php 


    session_start();
    ob_start();


    // configure the connection module
    require("connection.php");



    // getting all variables
    $one = $_POST["opt_code"];
    $two = $_POST["passcode"];
    $three = $_POST["retype_passcode"];
    $opt_code = htmlspecialchars($one);
    $password = htmlspecialchars($two);
    $retype = htmlspecialchars($three);

    // .. session storage of username
    $username = $_SESSION["new_account_storage"];


    //decate when a button is been clicked
    if(isset($_POST["verify_my_Account"])){
        // .. Do something

        // .. let check if the user verification code exist or not
        $select_code = mysqli_query($connect_db, "SELECT * FROM $username WHERE opt_code='$opt_code'");
        if($select_code){
            // ... we need to check if it exsit 
            $check_otp_code = mysqli_num_rows($select_code);
            if($check_otp_code > 0){
                //    ..  we need to check if password and retype password are equal
                if($password === $retype){
                    // .. naw update the user password
                    $update_password = "UPDATE $username SET passcode='$password' WHERE username='$username'";
                    if($connect_db->query($update_password) === TRUE){

                        $_SESSION["user_login_box"] = "block";
                        if(isset($_SESSION["user_login_box"])){
                            echo "<script>alert('Thank you for creating an account with us');</script>";
                            header("Location: index.php");
                        }   
                    }else{
                        echo "<script>alert('was unable to pass data');</script>";
                    }
                }else{
                    echo "<script>alert('Make sure the password is the same as the other');</script>";
                }
            }else{
                echo "<script>alert('Opps, seems the verification code is wrong');</script>";
            }
        }

    }


?>