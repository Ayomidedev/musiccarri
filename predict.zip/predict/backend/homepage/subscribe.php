<?php
 

 session_start();
 
 require("connection.php");


 $_SESSION["error_page"] = "none";

 // .. checking password
 $visitor_username = $_SESSION["no_active_user_information"];
 $user_password = $_POST["passcode"];


//  redirecting user, if username session was not cretaed
if(!isset($_SESSION["no_active_user_information"])){
    header("Location: /predict/");
}



if(isset($_POST["logout"])){
    session_destroy();
    header("Location: /predict/");
}


$_SESSION["hide_query_page"] = "block";
$_SESSION["hide_payment_page"] = "none";


if(isset($_POST["user_check"])){

    //  .. checking password
    $select_user_account = mysqli_query($connect_db, "SELECT * FROM $visitor_username WHERE passcode='$user_password'");
    if($select_user_account){
        $check_user_passcode = mysqli_num_rows($select_user_account);
        if($check_user_passcode > 0){
            // .. then proceed
            $_SESSION["hide_query_page"] = "none";
            $_SESSION["hide_payment_page"] = "block";
        }else{
            //.. we want to set error session
            $_SESSION["error_page"] = "block";
            $_SESSION["error_message"] = "The password for account ".$visitor_username." is incorrect ";
        }
    }

}




?>