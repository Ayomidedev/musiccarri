<?php 

    // putting required information inside a array
    
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "superbet";


    // connecting to thr database
    $connect_db = mysqli_connect(
        $host,
        $user,
        $password,
        $database
    );

    // checking if it connected
    if($connect_db){
        // echo "<script>alert('connected');</script>";
    }else{
        echo "<script>alert('error trying to connect');</script>";
    }

?>