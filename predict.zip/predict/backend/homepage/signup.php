<?php 

 
    session_start();
    ob_start();

    // adding the connection module
    require("connection.php");

    


     

     if(isset($_SESSION["dashboard_view"])){
        // show dashboard
         $_SESSION["hide_home_page_view_display"] = "none";
     }else{
        $_SESSION["dashboard_view"] = "block";
     }
    

     if(isset($_SESSION["hide_home_page_view_display"])){
        // show dashboard
         $_SESSION["hide_home_page_view_display"] = "block";
     }else{
        $_SESSION["dashboard_view"] = "none";
     }
    


    // getting all variable
    $one = $_POST["username"];
    $two = $_POST["email"];
    $three = $_POST["phoneno"];
    $username = htmlspecialchars($one);
    $email = htmlspecialchars($two);
    $phoneno = htmlspecialchars($three);
    $user_name = mysqli_escape_string($connect_db, $username);
    $user_mail = mysqli_escape_string($connect_db, $email);
    $user_phone = mysqli_escape_string($connect_db, $phoneno);





    // clickable events
    if(isset($_POST["create_my_account"])){
        // .. Do the scripted codes
        // first we need to crate a database
        // database => user_manager
        $create_tb = mysqli_query($connect_db, "CREATE TABLE user_manager(
            username VARCHAR(100),
            email VARCHAR(100)
        )");
        if($create_tb){

        }else{
            // echo "<script>alert('couldnt create user_manager database');</script>";
        }



        // now we need to check if the user information inserted already exist 
        // in the user_manager database before
        $select_user_name = mysqli_query($connect_db, "SELECT * FROM user_manager WHERE username='$user_name'");
        if($select_user_name){
            // check if it exsit
            $check_if_username_exist = mysqli_num_rows($select_user_name);
            if($check_if_username_exist > 0){
                echo "<script>alert('Sorry. The User information  ".$user_name." already exist in our database ');</script>";
            }else{
                 // ... check if the email exist also
                 $select_user_emails = mysqli_query($connect_db, "SELECT * FROM user_manager WHERE email='$email'");
                 if($select_user_emails){
                     // .. check if it exist
                     $check_mail = mysqli_num_rows($select_user_emails);
                     if($check_mail > 0){
                        echo "<script>alert('Sorry. The User information  ".$user_mail." already exist in our database ');</script>";
                     }else{
                        // .. insert datas inside user_managers
                        $insert_this = "INSERT INTO user_manager(username, email) VALUES (
                            '$user_name', '$user_mail'
                        )";
                        if($connect_db->query($insert_this) === TRUE){
                            // .... know we want this to create user database
                            $create_user_db = mysqli_query($connect_db, "CREATE TABLE $user_name(
                                 username VARCHAR(100),
                                email VARCHAR(100),
                                phonenumber INT(100),
                                passcode VARCHAR(100),
                                opt_code INT(100),
                                -- subscription datas
                                subscription_status VARCHAR(100),
                                timestamps VARCHAR(100),
                                membership_ending VARCHAR(100)
                            )");
                            if($create_user_db){
                                // ... we want to insert all user informations over there
                                $rands = rand();
                                $_SESSION["randomes"] = $rands;
                                $rand = $_SESSION["randomes"];


                                $insert_user_info = "INSERT INTO $user_name(
                                    username, email, phonenumber, passcode, opt_code, subscription_status, timestamps, membership_ending
                                ) VALUES (
                                    '$user_name', '$user_mail', '$user_phone', '@$%@#%@$%@$%@$%@$%', '$rand', 'no-active',
                                    'none', 'none'

                                )";


                                if($connect_db->query($insert_user_info) === TRUE){

                                    $from = "quadriaremu6@gmail.com";
                                    $to = $email;
                                    $message = "Welcome to BestOddssTation website, ".$user_name." . \n\n Please Your varification code is: ".$rand."\n";
                                    $send_receipt = mail($to, $from, $message); 
                                    if($send_receipt){
                                        echo "<script>alert('receiept has been sent');</script>";

                                        $_SESSION["new_account_storage"] = $user_name;
                                        if(isset($_SESSION["new_account_storage"])){
                                           if(!headers_sent()){
                                             header("Location: done.php");
                                           }else{
                                               echo "<script>window.location.href='done.php'";
                                           }
                                        }else{
                                            echo "<script>alert('couldnt create a session for the user');</script>";
                                        }
            
                                      
                                    }else{
                                        echo "<script>alert('error sending receipt');</script>";
                                    }

                            
                                

                                    
                                   
                                }else{

                                }
                               
                            }else{
                                echo "<script>alert('cant create user database');</script>";
                            }
                        }else{
                            echo "<script>alert('data was not inserted');</script>";
                        }
                     }















                 }
            }
        }   

    }
    



    





    $_SESSION["show_verification_area"] = "none";
    //  for desktop registrations
    if(isset($_POST["create_user_account"])){
        // .. for showing the box
        $_SESSION["display_sign_up_box"] = "block";


        // .. for showing the content
        $_SESSION["show_signup_content"] = "block";


        // .. close button
        $_SESSION["show_close_button"] = "block";

        // .. login
        $_SESSION["login_page_hide"] = "none";
    }


    if(isset($_POST["Login_user_account"])){
        $_SESSION["display_login_box"] = "block";
    }

    if(isset($_POST["close_user_account_box"])){
        $_SESSION["display_sign_up_box"] = "none";

        $_SESSION["show_verification_area"] = "none";

        $_SESSION["display_login_box"] = "none";
    }




    // values
    $user_name_d = mysqli_escape_string($connect_db, $_POST["username_d"]);
    $user_mail_d = mysqli_escape_string($connect_db, $_POST["user_mail_d"]);




    if(isset($user_name_d)){
         $_SESSION["display_user_exist_errot"] = "none";
    }
    if(isset($user_mail_d)){
        $_SESSION["display_user_exist_errot"] = "none";
   }


    $_SESSION["display_user_exist_errot"] = "none";
    if(isset($_POST["create_my_desktop_account"])){



        // we need to cehck if the email those not exist
        $select_user_desktop = mysqli_query($connect_db, "SELECT * FROM user_manager WHERE username='$user_name_d'");
        if($select_user_desktop){
            $check_if_desktop_user_exist = mysqli_num_rows($select_user_desktop);
            if($check_if_desktop_user_exist > 0){
                $_SESSION["display_user_exist_errot"] = "block";
                $_SESSION["user_exsit_error"] = "The user ".$user_name_d." already exist on our database";
            }else{
               $select_user_email_desktop = mysqli_query($connect_db, "SELECT * FROM user_manager WHERE email='$user_mail_d' ");
               if($select_user_email_desktop){
                    $check_if_user_email_Exist = mysqli_num_rows($select_user_email_desktop);
                    if($check_if_user_email_Exist > 0){
                        $_SESSION["display_user_exist_errot"] = "block";
                        $_SESSION["user_exsit_error"] = "The email is already in use";
                    }else{
                          // .. insert datas inside user_managers
                        $insert_this_d = "INSERT INTO user_manager(username, email) VALUES (
                            '$user_name_d', '$user_mail_d'
                        )";
                        if($connect_db->query($insert_this_d) === TRUE){
                            $create_user_db_d = mysqli_query($connect_db, "CREATE TABLE $user_name_d(
                                username VARCHAR(100),
                                email VARCHAR(100),
                                phonenumber INT(100),
                                passcode VARCHAR(100),
                                opt_code INT(100),
                                -- subscription datas
                                subscription_status VARCHAR(100),
                                timestamps VARCHAR(100),
                                membership_ending VARCHAR(100)
                                
                            )");
                            if($create_user_db_d){
                                // .. we want to insert user data
                                $rands = rand();
                                $_SESSION["randomes"] = $rands;
                                $rand = $_SESSION["randomes"];


                                $insert_user_info_d = "INSERT INTO $user_name_d(
                                    username, email, phonenumber, passcode, opt_code, subscription_status, timestamps, membership_ending
                                ) VALUES (
                                    '$user_name_d', '$user_mail_d', 'non-valid-desktop-account', '@$%@#%@$%@$%@$%@$%', '$rand', 'no-active',
                                    'none', 'none'

                                )";

                                if($connect_db->query($insert_user_info_d) === TRUE){


                                    // .... we need to set username on session
                                    $_SESSION["signup_desktop_username"] = $user_name_d;

                                    $_SESSION["user_email"] = $user_mail_d;
                                    // .. we want to send verification code
                                    $from = "quadriaremu6@gmail.com";
                                    $to = $user_mail_d;
                                    $message = "Welcome to SuperPrediction website, ".$user_name_d." . \n\n Please Your varification code is: ".$rand."\n";
                                    $send_receipt = mail($to, $from, $message); 
                                    if($send_receipt){
                                        // echo "<script>alert('receiept has been sent');</script>";
                                        // $_SESSION["new_account_storage"] = $user_name;
                                        // if(isset($_SESSION["new_account_storage"])){
                                        //     header("Location: done.php");
                                        // }else{
                                        //     echo "<script>alert('couldnt create a session for the user');</script>";
                                        // }
                                    }else{
                                        echo "<script>alert('error sending receipt');</script>";
                                    }



                                    //... then if email is sent. then do this
                                    $_SESSION["show_verification_area"] = "block";
                                    $_SESSION["show_signup_content"] = "none";
                                    $_SESSION["show_close_button"] = "none";

                                }

                            }
                        }else{
                            $_SESSION["display_user_exist_errot"] = "block";
                            $_SESSION["user_exsit_error"] = "cant create user account";
                        }
                    }
               }
            }
        }else{
           
        }

    }
   



    




    // ... verifying account on desktop
    if(isset($_POST["verify_my_account_on_desktop"])){
        // ... getting values
        $user_code = mysqli_escape_string($connect_db, $_POST["user_code_d"]);
        $user_passcode = mysqli_escape_string($connect_db, $_POST["user_passcode_d"]);

        $storage_user_name = $_SESSION["signup_desktop_username"];

        // .. check user code
        $select_code_d = mysqli_query($connect_db, "SELECT * FROM $storage_user_name WHERE opt_code='$user_code'");
        if($select_code_d){
            $check_code_d = mysqli_num_rows($select_code_d);
            if($check_code_d > 0){
                //.. update password
                $update_d_password = "UPDATE $storage_user_name SET passcode='$user_passcode' WHERE username='$storage_user_name'";
                if($connect_db->query($update_d_password) === TRUE){
                     $_SESSION["show_verification_area"] = "none";
                     $_SESSION["show_close_button"] = "none";

                     $_SESSION["login_page_hide"] = "block";
                }else{
                    $_SESSION["display_user_exist_errot"] = "block";
                    $_SESSION["user_exsit_error"] = "Cant create user account";
                }
            }else{
                $_SESSION["display_user_exist_errot"] = "block";
                $_SESSION["user_exsit_error"] = "The verification code ".$user_code." is wromg!!";
            }
        }
    }





    //... manuel account login in
    // that is the username is already provided
    if(isset($_POST["login_user_manually"])){

        $manual_username = $_SESSION["signup_desktop_username"];
        $manual_password = $_POST["mauel_password"];




        //check if password is correct
        $select_manual_user = mysqli_query($connect_db, "SELECT * FROM $manual_username WHERE passcode='$manual_password'");
        $check_menu_password = mysqli_num_rows($select_manual_user);

        if($check_menu_password > 0){

            // .. fatching user data
            $select_user_status = mysqli_query($connect_db, "SELECT * FROM $select_manual_user");
            while($fetch_status = mysqli_fetch_assoc($select_user_status)){
                $status = $fetch_status["subscription_status"];
                switch ($status){
                    case "active":

                            //we need to check if it is expired or not
                            $select_expires = mysqli_query($connect_db, "SELECT * FROM  $manual_username");
                            while($expires_fetch = mysqli_fetch_assoc($select_expires)){
                                $expiring_date = $expires_fetch["membership_ending"];
                                if(date('y-m-d') > $expiring_date){

                                    //we want to set back status and date to zero
                                    $update_status = "UPDATE $manual_username SET subscription_status='no-active' WHERE username='$manual_username'";
                                    if($connect_db->query($update_status) === TRUE){

                                        // .. update TimeStamps
                                        $update_timestamps = "UPDATE $manual_username SET timestamps='none' WHERE username='$manual_username'";
                                        if($connect_db->query($update_timestamps) === TRUE){

                                            // .. update expiring date to none
                                            $update_membership_ending = "UPDATE $manual_username SET membership_ending='none' WHERE username='$manual_username'";
                                            if($connect_db->query($update_membership_ending) === TRUE){
                                                header("Location: expired.php");
                                            }else{
                                                echo "<script>alert('check your connection');</script>";
                                            }

                                        }else{
                                            echo "<script>alert('check your connection');</script>";
                                        }

                                    }else{
                                        echo "<script>alert('check your connection');</script>";
                                    }

                                }else{
                                    $_SESSION["login_page_hide"] = "none";
                                    //.... we want to set a sessions to hide the login page and open dash baord
                                    $_SESSION["display_sign_up_box"] = "none";
                                    // hide home_page_view_display
                                    $_SESSION["hide_home_page_view_display"] = "none";
                                    // show dashboard
                                    $_SESSION["dashboard_view"] = "block";
                                }
                            }
                        break;

                    case "no-active":
                        header("Location:subscribe.php");
                        break;
                    
                    case "expired":
                        header("Location:subscribe.php");
                        break;
                }
            }
    
          
        }else{
            $_SESSION["display_user_exist_errot"] = "block";
            $_SESSION["user_exsit_error"] = "Opps, The password to account ".$manual_username." is wrong ! ";
        }


    }






    // .... logging out desktop views
    if(isset($_POST["logout"])){
        $_SESSION["display_user_exist_errot"] = "none";
        $_SESSION["hide_home_page_view_display"] = "block";
        if(isset($_SESSION["display_user_exist_errot"])){
            session_destroy();
            header("Location: /predict/");
        }
    }


 









    // ..... Logining user
    if(isset($_POST["log_user_in"])){
        
        //..  getting values
        $login_username = mysqli_escape_string($connect_db, $_POST["login_username"]);
        $login_password = mysqli_escape_string($connect_db, $_POST["password_password"]);

        $select_real_user_login = mysqli_query($connect_db, "SELECT * FROM $login_username WHERE username='$login_username'");
        if($select_real_user_login){
            $check_real_user_login = mysqli_num_rows($select_real_user_login);
            if($check_real_user_login > 0){

                // check pass
                $select_real_passcode_login = mysqli_query($connect_db, "SELECT * FROM $login_username WHERE passcode='$login_password'" );
                if($select_real_passcode_login){
                    $check_real_password_login = mysqli_num_rows($select_real_passcode_login);
                    if($check_real_password_login > 0){


                        // .. check if user is subscribe or not
                        $select_user_status = mysqli_query($connect_db, "SELECT * FROM $login_username");
                        while($fetch = mysqli_fetch_assoc($select_user_status)){
                            $user_status = $fetch["subscription_status"];

                            switch ($user_status){
                                case "active":
                                        $select_expires = mysqli_query($connect_db, "SELECT * FROM  $login_username");
                                        while($expires_fetch = mysqli_fetch_assoc($select_expires)){
                                            $expiring_date = $expires_fetch["membership_ending"];
                                            if(date('y-m-d') > $expiring_date){

                                                //we want to set back status and date to zero
                                                $update_status = "UPDATE $login_username SET subscription_status='no-active' WHERE username='$login_username'";
                                                if($connect_db->query($update_status) === TRUE){

                                                    // .. update TimeStamps
                                                    $update_timestamps = "UPDATE $login_username SET timestamps='none' WHERE username='$login_username'";
                                                    if($connect_db->query($update_timestamps) === TRUE){

                                                        // .. update expiring date to none
                                                        $update_membership_ending = "UPDATE $login_username SET membership_ending='none' WHERE username='$login_username'";
                                                        if($connect_db->query($update_membership_ending) === TRUE){
                                                            header("Location: expired.php");
                                                        }else{
                                                            echo "<script>alert('check your connection');</script>";
                                                        }

                                                    }else{
                                                        echo "<script>alert('check your connection');</script>";
                                                    }

                                                }else{
                                                    echo "<script>alert('check your connection');</script>";
                                                }

                                            }else{
                                                //.... we want to set a sessions to hide the login page and open dash baord
                                                $_SESSION["display_login_box"] = "none";

                                                // hide home_page_view_display
                                                $_SESSION["hide_home_page_view_display"] = "none";

                                                // show dashboard
                                                $_SESSION["dashboard_view"] = "block";

                                                //_ set user token
                                                $_SESSION["user_untachible_token"] = $login_username;
                                            }
                                        }
                                    break;
                                
                                case "no-active":
                                    $_SESSION["no_active_user_information"] = $login_username;
                                    if(isset($_SESSION["no_active_user_information"])){
                                        header("Location: subscribe.php");
                                    }else{
                                        echo "<script>alert('error 7000');</script>";
                                    }
                                    break;
                                
                                case "expired":
                                    header("Location: subscribe.php");
                                    break;

                            }
                        }

                        
            

                    }else{
                        $_SESSION["display_user_exist_errot"] = "block";
                        $_SESSION["user_exsit_error"] = "Opps, The password is account ".$login_username." is wrong ! ";
                    }
                }
                
            }else{
                $_SESSION["display_user_exist_errot"] = "block";
                $_SESSION["user_exsit_error"] = "Opps, there is no such account with our company";
            }
        }
    }





?>