<?php 
    
//  getting tha values
$prefer_plans = $_POST["user_plan"];


//  .. Time Zoon
date_default_timezone_set("USA");

require("connection.php");


if(isset($_POST["user_check"])){
    $_SESSION["price"] = $prefer_plans;
}



 //settiing a swtich statements
 switch($prefer_plans){
    case "100": 

        // ... setting all cookies
        $timestamps = date('y-m-d');
        $membership_expirationg = date('y-m-d', strtotime(date('y-m-d', strtotime($timestamps)). '+ 365 day'));

         // current year
         $_SESSION["main_year"] = $timestamps;
         // current month is string
         unset($_SESSION["sub_type"]);
         $_SESSION["main_month"] = $membership_expirationg;
         $_SESSION["sub_type"] = "1 year subscribtion";$_SESSION["price"] = $prefer_plans;
        
        break;
    case "50":

        
       
        // ... setting all cookies
        $timestamps = date('y-m-d');
        $membership_expirationg = date('y-m-d', strtotime(date('y-m-d', strtotime($timestamps)). '+ 182 day'));

         // current year
         $_SESSION["main_year"] = $timestamps;
         // current month is string
         $_SESSION["main_month"] = $membership_expirationg;



         $_SESSION["price"] = $prefer_plans;
         unset($_SESSION["sub_type"]);
         $_SESSION["sub_type"] = "half a year subscribtion";$_SESSION["price"] = $prefer_plans;


        break;

    case "30":

        
       
        // ... setting all cookies
        $timestamps = date('y-m-d');
        $membership_expirationg = date('y-m-d', strtotime(date('y-m-d', strtotime($timestamps)). '+ 30 day'));

         // current year
         $_SESSION["main_year"] = $timestamps;
         // current month is string
         $_SESSION["main_month"] = $membership_expirationg;

         $_SESSION["price"] = $prefer_plans;
         unset($_SESSION["sub_type"]);
         $_SESSION["sub_type"] = "A month subscribtion";$_SESSION["price"] = $prefer_plans;

        break;
    
    case "10":

      
        // ... setting all cookies
        $timestamps = date('y-m-d');
        $membership_expirationg = date('y-m-d', strtotime(date('y-m-d', strtotime($timestamps)). '+ 7 day'));

         // current year
         $_SESSION["main_year"] = $timestamps;
         // current month is string
         $_SESSION["main_month"] = $membership_expirationg;$_SESSION["price"] = $prefer_plans;

         $_SESSION["price"] = $prefer_plans;
         unset($_SESSION["sub_type"]);
         $_SESSION["sub_type"] = "1 week subscribtion";
        


        break;
    default:
        echo "<script>alert('please select a plan, to proceed');</script>";
 }






 if(isset($_POST["pay"])){


    // current year
    $date_one = $_SESSION["main_year"];
    // current month is string
    $date_two = $_SESSION["main_month"];
    //. user name database
    $_user_name = $_SESSION["no_active_user_information"];



    // ... we want to update user information
    // subscription_status, timestamps, membership_ending.
    $update_activestatus = "UPDATE $_user_name SET subscription_status='active' WHERE username='$_user_name'";
    if($connect_db->query($update_activestatus) === TRUE){
        // .. update timestamps
        $update_time_stamps = "UPDATE $_user_name SET timestamps='$date_one' WHERE username='$_user_name'";
        if($connect_db->query($update_time_stamps) === TRUE){
            $update_membership_expires = "UPDATE $_user_name SET membership_ending='$date_two' WHERE username='$_user_name'";
            if($connect_db->query($update_membership_expires) === TRUE){
                // .... 
                header("Location: success.php");
            }else{
                echo "<script>alert('check your connection, there was an error');</script>";
            }
        }else{
            echo "<script>alert('check your connection, there was an error');</script>";
        }
    }else{
        echo "<script>alert('check your connection, there was an error');</script>";
    }



 }

?>