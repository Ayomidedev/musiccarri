<?php 

    session_start();
    ob_start();

    // adding the connection module
    require("connection.php");



    // getting all variable
    $one = $_POST["userlogin"];
    $two = $_POST["userpasscode"];
    $username = htmlspecialchars($one);
    $passocde = htmlspecialchars($two);
    $user_name = mysqli_escape_string($connect_db, $username);
    $user_passcode = mysqli_escape_string($connect_db, $passocde);






    // if(isset($_POST["logmein_my_account"])){

    //     if(strlen($user_name) > 10){
    //         echo "<script>alert('username can not be as long as Ten(10) characters');</script>";
    //     }else{
    //         // .. we need to check if user exist and connect to user page
    //         $select_from_username = mysqli_query($connect_db, "SELECT * FROM $user_name");
    //         if($select_from_username){
    //             // .. know we need to check if the password ryhmes since the username exist in our db
    //             // .. check password
    //             $check_password = mysqli_query($connect_db, "SELECT * FROM $user_name WHERE passcode='$user_passcode'");
    //             // .. checking password
    //             // .. checking password
    //             $check_password_exist = mysqli_num_rows($check_password);
    //             if($check_password_exist > 0){
    //                 header("Location: dashboard/dashboard.php");
    //             }else{
    //                 echo "<script>alert('Insert the correct password to account,  ".$user_name."');</script>";
    //                 $_SESSION["user_login_box"] = "block";
    //             }
    //         }else{
    //             echo "<script>alert('The name ".$user_name.", Does not exist as an acount with our company');</script>";
    //             $_SESSION["user_login_box"] = "block";
    //         }
    //     }

    // }






    // we want to log user in here
    if(isset($_POST["logmein_my_account"])){


        // we need to check how long the username is
        if(strlen($user_name) > 10){
            echo "<script>alert('username can not be as long as Ten(10) characters');</script>";
        }else{
            // .. we need to check if user exist and connect to user page
            $select_from_username = mysqli_query($connect_db, "SELECT * FROM $user_name");
            if($select_from_username){
                // .. know we need to check if the password ryhmes since the username exist in our db
                // .. check password
                $check_password = mysqli_query($connect_db, "SELECT * FROM $user_name WHERE passcode='$user_passcode'");
                // .. checking password
                $check_password_exist = mysqli_num_rows($check_password);
                if($check_password_exist > 0){
                    // .. we need to fetch the user stutus first
                    // knowing if user has subscribed or not
                    // .. set a session and set location to user account
                    $_SESSION["current_acount_storage"] = $user_name;
                    if(isset($_SESSION["current_acount_storage"])){

                        $user_details = $_SESSION["current_acount_storage"];
                        $fetch_data = mysqli_query($connect_db, "SELECT * FROM $user_details");
                        if($fetch_data){
                            // echo "<script>alert('selected');</script>";
                        }else{
                            echo "<script>alert('not selected');</script>";
                        }
                        while($datars = mysqli_fetch_assoc($fetch_data)){
                            $status = $datars["subscription_status"];

                            switch ($status){
                                case "active":
                                    
                                    // ... we want to check if user account is expired or not
                                    $select_user_expiring_date = mysqli_query($connect_db, "SELECT * FROM $user_name");
                                    while($data_x = mysqli_fetch_assoc($select_user_expiring_date)){
                                        $ex_date = $data_x["membership_ending"];
                                        if(date("y-m-d'") > $ex_date){
                                            
                                             //we want to set back status and date to zero
                                             $update_status = "UPDATE $user_name SET subscription_status='no-active' WHERE username='$user_name'";
                                             if($connect_db->query($update_status) === TRUE){
 
                                                 // .. update TimeStamps
                                                 $update_timestamps = "UPDATE $user_name SET timestamps='none' WHERE username='$user_name'";
                                                 if($connect_db->query($update_timestamps) === TRUE){
 
                                                     // .. update expiring date to none
                                                     $update_membership_ending = "UPDATE $user_name SET membership_ending='none' WHERE username='$user_name'";
                                                     if($connect_db->query($update_membership_ending) === TRUE){
                                                         header("Location: expired.php");
                                                     }else{
                                                         echo "<script>alert('check your connection');</script>";
                                                     }
 
                                                 }else{
                                                     echo "<script>alert('check your connection');</script>";
                                                 }
 
                                             }else{
                                                 echo "<script>alert('check your connection');</script>";
                                             }
                                            
                                        
                                        }else{
                                            // .. open user dashboard  welcome view area.
                                            header("Location: dashboard/dashboard.php");
                                            $_SESSION["user_login_box"] = "none";
                                            echo "<script>alert('3');</script>";
                                        }
                                    }

                                    
                                break;

                                case "no-active":
                                    // .. we want to open subscription page
                                    // session_destroy();
                                    unset($_SESSION["current_acount_storage"]);
                                    //.. we want to create another session again
                                    $_SESSION["subscribe_name"] = $user_name;
                                    if(isset($_SESSION["subscribe_name"])){
                                        header("Location: dashboard/subscribe.php");  
                                        $_SESSION["user_login_box"] = "none"; 
                                    }else{
                                        // .. do something terrible 
                                    }
                                    break;
                                case "expired":
                                    // .. we want to open subscription page
                                    header("Location: dashboard/subscribe.php");
                                    $_SESSION["user_login_box"] = "none";
                                    break;
                                default:
                                    echo "<script>alert('error occur');</script>";
                                    $_SESSION["user_login_box"] = "none";
                                    break;
                            }
                        }


                        
                    }
                }else{
                    echo "<script>alert('Insert the correct password to account,  ".$user_name."');</script>";
                    $_SESSION["user_login_box"] = "block";
                }
            }else{
                echo "<script>alert('The name ".$user_name.", Does not exist as an acount with our company');</script>";
                $_SESSION["user_login_box"] = "block";
            }
        }
    }





    if(isset($_POST["closesession"])){
        $_SESSION["user_login_box"] = "none";
    }








    // sending feedbacks
    if(isset($_POST["send_feedback"])){

        $name = $_POST["name"];
        $email_address = $_POST["email_address"];
        $user_message = $_POST["message"];


        // seending mail
        $to =  "quadriaremu6@gmail.com";
        $from = $email_address;
        $message = "
            ".$email_address." with the name ".$name." send a feedback \n\n\n
            feedback: \n\n ".$user_message."
        ";  

        $mail_ = mail($to, $from, $message);
        if($mail_){
            echo "<script>alert('Thank you, your feedback has been sent');</script>";
        }else{
            echo "<script>alert('couldnt send feedback, sorry');</script>";
        }
    }










?>