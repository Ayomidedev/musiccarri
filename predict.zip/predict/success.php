<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="customizations/responsiveness/others.css">


    <div class="hidden">
        <?php 
            require("backend/homepage/history_database.php");
        ?>  
    </div>
</head>
<body>
    <div class="receipts">
        <div class="title_bar"><h2>welcome, <?php echo  $_SESSION["subscribe_name"]; ?></h2>
        <span>Please, this is your recipt to your subscription</span>
        </div>

        <div class="recip">
            <p>name: <span style="font-weight:bold; color:blue;"><?php echo $_SESSION["subscribe_name"]; ?></span></p>
            <p>amount: <span style="font-weight:bold; color:blue;"><?php echo $_SESSION["price"]; ?></span></p>
            <p>type of subscription: <span style="font-weight:bold; color:blue;"><?php echo $_SESSION["sub_type"]; ?></span></p>
            <p>time: <span style="font-weight:bold; color:blue;"><?php echo $_SESSION["time"]; ?></span></p>
            <p>valid till: <span style="font-weight:bold; color:blue;"><?php echo $_SESSION["main_month"]; ?></span></p>
        </div>


        <div class="thank_you_text">
            <p>Thank you, for subscribing to our website. </p>
        </div>

        <form action="" method="POST">
            <button name="end_progress">Please click to login again</button>
        </form>
    </div>
</body>
</html>



<link rel="stylesheet" href="customizations/responsiveness/otherres.css">