<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(()=>{
        $("body").load("../index.php");
    })
</script>
