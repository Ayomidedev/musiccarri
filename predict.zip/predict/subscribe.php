<?php 

    session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>subscripe</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="welcome to our website, we give you correct and standard betting Tips, to make you become a winner. Our AI helps predict correct match scores with 100% sure gurantee">
    <meta name="author" content="web plugs">
    <meta name="keyword" content="betting, predict, predictions, games, football, basketball, planing, money, gambling, gaming, computer, sex">

    <!-- social medias -->
    <meta property="og:site_name" content="bestoddsstation.com">
    <meta property="og:title" content="bestoddsstation">
    <meta property="descript" content="Get sure predicted betting games tips">

    <!-- imgaes -->
    <meta property="og:image" itemprop="image" content="asset/ayo.png">
    <meta property="og:type" content="image/png">
    <meta property="og:image:width" content="400">
    <meta property="og:image:height" content="400">


    <link rel="shortcut icon" href="asset/content.png" type="image/png">




    <title>subscribe</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">

    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />





    <!-- css linking -->
    <link rel="stylesheet" href="customizations/homepage/desktop/subscribe.css">


    <div class="hidden_file">
        <?php 
            require("backend/homepage/subscribe.php");
            require("backend/homepage/subscript_date.php");
        ?>
    </div>


</head>
<body>
    

    <div class="box">
        <div class="mover" style="display:<?php echo $_SESSION["hide_query_page"]; ?> ;"> 
            <center>
                <div class="container">
                    <div class="all_content">

                        <center><h3><span style="color:grey;">welcome</span>, <?php echo $_SESSION["no_active_user_information"]; ?></h3></center>

                       <div class="title">
                           <p><b>BestOddsStation</b></p>
                           <p class="subtitle">subscribe to your account, in other to proceed</p>
                       </div>


                       <!-- form handlers -->
                       <div class="form_handler">
                           
                           <form action="" method="post">
                               <div class="input_box">
                                   <span>select plan</span>
                                   <div class="input">
                                        <select name="user_plan" id="" required>
                                            <option value="">select suitable plans</option>
                                            <option value="100">100$ -1year subscription</option>
                                            <option value="50">50$ -Half a year subscription</option>
                                            <option value="30">30$ -1 month subscription</option>
                                            <option value="10">10$ -1 week subscription</option>
                                        </select>
                                   </div>
                               </div>
                               <br>
                               <div class="input_box">
                                   <span>Insert your password</span>
                                   <div class="input">
                                        <input type="password" placeholder="enter your password" name="passcode" required>
                                   </div>
                               </div>
                              <div class="button">
                                <button name="user_check">
                                    Procced Checkout
                                </button>
                              </div>
                           </form>

                           <div class="logout_button">
                               <form action="" method="post">
                                    <center><button name="logout">logout</button></center>
                               </form>
                           </div>

                          <div class="move_down" style="display:<?php echo $_SESSION["error_page"] ; ?>;">
                            <div class="error_area">
                              <center>
                                <span><?php echo $_SESSION["error_message"] ?></span>
                              </center>
                            </div>
                          </div>

                       </div>

                    </div>
                </div>
            </center>
        </div>
















        <div class="mover" style="display:<?php echo $_SESSION["hide_payment_page"]; ?> ;">
           <center>
                <div class="container">
                    <div class="all_content">
                    
                        <center><h3><span style="color:grey;">Let Continue your processing</span>, <?php echo $_SESSION["no_active_user_information"]; ?></h3></center>

                        <div class="title" style="padding-top:1px;">
                            <p><b>BestOddsStation</b></p>
                            <p class="subtitle">subscribe to your account, in other to proceed</p>
                        </div>



                        <div class="details">
                            <div class="holder">
                                <div class="left_d"><i class="fa-solid fa-calendar-check"></i> Subscription date</div>
                                <div class="right_d"><?php echo $_SESSION["main_year"];?> </div>
                            </div>
                            <div class="holder">
                                <div class="left_d"><i class="fa-solid fa-calendar-check"></i> Expiring Date</div>
                                <div class="right_d"><?php echo $_SESSION["main_month"]; ?></div>
                            </div>      
                        </div>

                        <div class="pay_button">
                            <form action="" method="post">
                               <center> <button name="pay">Pay naw</button></center>
                            </form>
                        </div>

                        <div class="logout_button">
                            <form action="" method="post">
                                <center><button name="logout">logout</button></center>
                            </form>
                        </div>
                        

                    </div>
                </div>
           </center>
        </div>

    </div>

</body>
</html>