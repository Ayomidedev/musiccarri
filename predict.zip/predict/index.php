<?php 

 session_start();
 ob_start();
?> 

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="welcome to our website, we give you correct and standard betting Tips, to make you become a winner. Our AI helps predict correct match scores with 100% sure gurantee">
    <meta name="author" content="bestoddsstation">
    <meta name="keyword" content="betting, predict, predictions, games, football, basketball, planing, money, gambling, gaming, computer, gaming">

    <!-- social medias -->
    <meta property="og:site_name" content="bestoddsstation.com">
    <meta property="og:title" content="bestoddsstation">
    <meta property="descript" content="Get sure predicted betting games tips">

    <!-- imgaes -->
    <meta property="og:image" itemprop="image" content="asset/ayo.png">
    <meta property="og:type" content="image/png">
    <meta property="og:image:width" content="400">
    <meta property="og:image:height" content="400">


    <link rel="shortcut icon" href="./asset/content.PNG" type="image/PNG">




    <title>Best Odds Station</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">

    <!--icon-->
    <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- flag icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/2.8.0/css/flag-icon.min.css" integrity="sha512-qBHaRLQnXdZXB6c5ryUXUy/9C6uqMgMYh0HGXZsOGCYJNDkdo46eHPbBPY7URCxyBG/cYpyCQsgIS5xyfWx4Nw==" crossorigin="anonymous" referrerpolicy="no-referrer" />



    <!-- desktop screen linking -->


    <!-- mobile screen linking -->
    <link rel="stylesheet" href="customizations/homepage/mobile/loading_screen.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/header.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/content.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/content_holder.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/registrationpage.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/footer.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/aboutus.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/pricing_m.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/near_games_mobile.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/contactus.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/drop_btn.css">
    <link rel="stylesheet" href="customizations/homepage/mobile/american_football.css">






    <!-- desktop linking -->
    <link rel="stylesheet" href="customizations/homepage/desktop/header.css">
    <link rel="stylesheet" href="customizations/homepage/desktop/user_render_views.css">
    <link rel="stylesheet" href="customizations/homepage/desktop/create_account.css">
    <link rel="stylesheet" href="customizations/homepage/desktop/dashboard_script.css">
    <link rel="stylesheet" href="customizations/homepage/desktop/footer.css">
    <link rel="stylesheet" href="customizations/homepage/desktop/otherdesign.css">


    <!-- script for mobile views -->
    <script src="functionalities/homepage/viewschanger.js"></script>
    <script src="functionalities/homepage/menus.js"></script>
    <script src="functionalities/homepage/football.js"></script>



    <div class="hidden_files" style="display:none;">
        <!-- the php linkings -->
        <?php 
            require("backend/homepage/connection.php");
            require("backend/homepage/signup.php");
            require("backend/homepage/login_user.php");
            require("backend/homepage/render_games.php");
        ?>
    </div>



    <script>
        if(window.history.replaceState){
            window.history.replaceState(null, null, window.location.href);
        }
    </script>

    <script>
            
            window.addEventListener("load", function(){
                document.getElementById("loading_screen").style.display = "none";
                document.getElementById("desktop_view").style.display = "block";
            })
    </script>


</head>
<body>

    <!-- desktop views -->
    <div class="desktop_views" id="desktop_view">
        <!-- content of desktop start here -->



        <div class="codexxxxxxxxxxs" style="display:<?php echo $_SESSION["hide_home_page_view_display"]; ?>;">
            <div class="header_d">
                    <center><span>welcome to bestoddsstation</span></center>
            </div>
            <div class="header_tow">
                <div class="left_name">
                    <span><i class="fa-solid fa-futbol"></i> Bestodds<span style="color:tomato;">station</span></span>
                </div>
                <div class="right_name">
                    <form action="" method="POST">
                        <button name="create_user_account"><i class="fa-solid fa-circle-plus"></i> create account</button>
                        <button name="Login_user_account"><i class="fa-solid fa-user"></i> Login account</button>
                </form>
                </div>
            </div>
            <div class="header_three">
                <!-- contents -->
                <div class="meuns_d">
                    <a href="#"><i class="fa-solid fa-house"></i> Home</a>
                    <a href="#" id="about_d_us"><i class="fa-solid fa-user"></i> About Us</a>
                    <a href="#" id="pricing_one"><i class="fa-solid fa-tags"></i> Pricing</a>
                    <a href="#" id="learn_hot_to"><i class="fa-solid fa-school"></i>How to predict</a>
                    <a href="#"><i class="fa-solid fa-id-badge"></i> Contact us</a>
                </div>
                <div class="menus_d_right">
                    <a href="#" id="Tab1"><i class="fa-solid fa-futbol"></i>Football</a>
                    <a href="#" id="Tab2"><i class="fa-solid fa-football"></i> American football</a>
                    <a href="#">Others</a>
                </div>
            </div>







            <!-- under the css properties of desktop/user_render_views.css -->
            <div class="user_render_views_page" id="football_life_view">
                <!-- content of user render views is here -->


                <div class="center_content_landing_page">
                    <!-- content -->
                    <center>
                        <div class="center_content">
                            <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                            <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                        </div>
                    </center>
                </div>







                <div class="drop_down_matches"> 
                    <!-- this area display the life matched --> 

                    <div class="titl" id="live_title">
                        <span>Current Live Scores</span>
                    </div>
                    <div class="titlr" id="upcoming_title">
                        <span>Next Features</span>
                    </div>
                    <div class="mob">
                        <div class="meuns_f">
                            <a href="#" id="live_button"><i class="fa-solid fa-house"></i> FootBall Score</a>
                            <a href="#" id="upcoming_button"><i class="fa-solid fa-user"></i> Upcoming Football Matched</a>
                            <a href="#" id="predict_Desktop"><i class="fa-solid fa-tags"></i> Predicted score</a>
                        </div>
                    </div>

                    <div class="row_d" id="live_matached">
                        <?php 
                            // .. we want to fetch data for real matches
                            $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM current_life_matchaes order by id desc");
                            while($data = mysqli_fetch_assoc($fecth_real_datas)){
                        ?>
                        <div class="column_d">
                            <div class="team_handle">
                               <span>
                                   <!-- time management -->
                                   <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["time"]; ?></span><br><br>
                                   <!-- time management ends here -->
                                   <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_a_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_a_name"]; ?></b></span></span>
                                   <span><b>vs</b></span>
                                   <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_b_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_b_name"]; ?></b></span></span>
                               </span>
                            </div>
                            <div class="score_handle">
                                <!-- <p>welcome2</p> -->
                               <span><b>click to get match details</b></span>
                            </div>
                            <div class="button_handle">
                                <button>preview game</button>
                            </div>
                            <div class="percentage_handle">
                                <!-- <p>welcome4</p> -->
                                 <!-- <p>welcome2</p> -->
                                 (<span id="team_a_score"><?php echo $data["team_a_percentage"]; ?>%</span>
                                 <span><i class="fa-solid fa-minus"></i></span>
                                 <span id="team_b_score"><?php echo $data["team_b_percentage"]; ?>%</span>)
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>









                    <!-- upcoming games -->
                    <div class="row_up" id="upcoming_games">
                        <?php 
                            $select_upcoming_games_desktop = mysqli_query($connect_db, "SELECT * FROM upcoming_games_management");
                            while($data2_d = mysqli_fetch_assoc($select_upcoming_games_desktop)){
                        ?> 
                        <div class="columnb_coming">
                            <div class="main_side_one">
                               <div class="left_i"> <span style="color:grey; font-size:10px;"><?php echo $data2_d["title"]; ?></span><br></div>
                               <div class="right_i"><span>Time: <span><?php echo $data2_d["months"]; ?></span>,<span><?php echo $data2_d["timess"]; ?></span></span></div>

                               <div class="teams_coming_up">
                                   <div class="team_l"><center><span><span class="flag-icon flag-icon-<?php echo $data2_d["team_a_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $data2_d["team_a_name"]; ?></span></span></center></div>
                                   <div class="center_o"><span id="conpetitorsign">Vs</span></div>
                                   <div class="team_r"><center><span><span class="flag-icon flag-icon-<?php echo $data2_d["team_b_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $data2_d["team_b_name"]; ?></span></span></center></div>
                               </div>
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                    
                    <!-- this area ends the life matched -->
                </div>


                <!-- ends here -->
            </div>
















            <!-- american fooball -->
            <!-- this area holds life american football -->
             <!-- under the css properties of desktop/user_render_views.css -->
            <div class="user_render_views_page_two" id="american_football_views">
                <!-- content of user render views is here -->


                <div class="center_content_landing_page">
                    <!-- content -->
                    <center>
                        <div class="center_content">
                            <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                            <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                        </div>
                    </center>
                </div>







                <div class="drop_down_matches">
                    <!-- this area display the life matched --> 

                    <div class="titl" id="live_title_2">
                        <span>Live American FootBall Scores</span>
                    </div>
                    <div class="titlr" id="upcoming_title_2">
                        <span>Next Features</span>
                    </div>
                    <div class="mob">
                        <div class="meuns_f">
                            <a href="#" id="live_button_2"><i class="fa-solid fa-house"></i> America Live Football matched</a>
                            <a href="#" id="upcoming_button_2"><i class="fa-solid fa-user"></i> Upcoming matches</a>
                            <a href="#" id="predict_Desktop_2"><i class="fa-solid fa-tags"></i> Predicted score</a>
                        </div>
                    </div>

                    <div class="row_d" id="live_matached_2">
                        <?php 
                            // .. we want to fetch data for real matches
                            $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM live_american_matched order by id desc");
                            while($data = mysqli_fetch_assoc($fecth_real_datas)){
                        ?>
                        <div class="column_d">
                            <div class="team_handle">
                               <span>
                                   <!-- time management -->
                                   <span style="color:grey; font-size:10px;"><i class="fa-solid fa-clock"></i><?php echo $data["timeer"]; ?></span><br><br>
                                   <!-- time management ends here -->
                                   <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_a_country"]; ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_a_name"]; ?></b></span></span>
                                   <span style="color:red;"><b>vs</b></span>
                                   <span id="country_a"><span class="flag-icon flag-icon-<?php echo $data["team_b_country"];  ?>" style="z-index:-1;"></span> <span id="team_a_name"><b><?php echo $data["team_b_name"]; ?></b></span></span>
                               </span>
                            </div>
                            <div class="score_handle">
                                <!-- <p>welcome2</p> -->
                               <span><b>click to get match details</b></span>
                            </div>
                            <div class="button_handle">
                                <button>preview game</button>
                            </div>
                            <div class="percentage_handle">
                                <!-- <p>welcome4</p> -->
                                 <!-- <p>welcome2</p> -->
                                 (<span id="team_a_score"><?php echo $data["team_a_percentage"] ?>%</span>
                                 <span><i class="fa-solid fa-minus"></i></span>
                                 <span id="team_b_score"><?php echo $data["team_b_percentage"]; ?>20%</span>)
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>









                    <!-- upcoming games -->
                    <div class="row_up" id="upcoming_american_games">
                        <?php 
                            $select_upcoming_america_matches = mysqli_query($connect_db, "SELECT * FROM upcoming_american_games_management order by id desc");
                            while($fetch_upcoming = mysqli_fetch_assoc($select_upcoming_america_matches)){
                        ?>
                        <div class="columnb_coming">
                            <div class="main_side_one">
                               <div class="left_i"> <span style="color:grey; font-size:10px;"><?php echo $fetch_upcoming["title"]; ?></span><br></div>
                               <div class="right_i"><span>Time: <span><?php echo $fetch_upcoming["months"]; ?></span>,<span><?php echo $fetch_upcoming["timess"]; ?></span></span></div>

                               <div class="teams_coming_up">
                                   <div class="team_l"><center><span><span class="flag-icon flag-icon-<?php echo $fetch_upcoming["team_a_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $fetch_upcoming["team_a_name"]; ?></span></span></center></div>
                                   <div class="center_o"><span id="conpetitorsign">Vs</span></div>
                                   <div class="team_r"><center><span><span class="flag-icon flag-icon-<?php echo $fetch_upcoming["team_b_country"]; ?>" style="z-index:-1;"></span> <br><span class="team_name_bn"><?php echo $fetch_upcoming["team_b_name"]; ?></span></span></center></div>
                               </div>
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                    
                    <!-- this area ends the life matched -->
                </div>


                <!-- ends here -->
            </div>



















          
            <div class="safe_guards">
                <div class="footer">
                    <!-- content of footer goes in here -->
                    <div class="footer_content">
                        <div class="title">
                            <span><i class="fa-solid fa-futbol"></i> Bestodds<span style="color:tomato;">station</span></span>
                        </div>

                        <div class="mover">
                            <div class="left_footer_content">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" id="contact_bb_1">Contact us</a>
                                    <a href="../index.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_2">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_3">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_d_three">About Us</a>
                                    <a href="#"  id="send_feedback_D">FeedBacks</a>
                                </div>
                            </div>
                            <div class="leflt_footer_content_4">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- content ends here -->
                </div>  
            </div>












            <div class="create_accounts" style="display:<?php echo $_SESSION["display_sign_up_box"]; ?>;">
                <!-- under the css propeties of desktop/create_account.css -->
                <center>
                    <div class="mover">
                        <div class="display_vies">  

                                <div class="close_icon" style="display:<?php echo $_SESSION["show_close_button"]; ?>;">
                                    <form action="" method="post">
                                        <button name="close_user_account_box"><i class="fa-solid fa-xmark"></i></button>
                                    </form>
                                </div>

                                <div class="content_for_sign" style="display:<?php echo  $_SESSION["show_signup_content"]; ?>;">
                                    <div class="title_d">
                                        <h2>create account</h2>
                                    </div>



                                    <div class="reg_d">
                                        <!-- registration content goes in here -->
                                        <form action="" method="post" autocomplete="off">
                                            <div class="hold_input">
                                                <div class="box">
                                                    <label for=""><span>username</span></label><br>
                                                    <div class="content_input">
                                                        <input type="text" name="username_d" id="" placeholder="username" required> <i class="fa-solid fa-user"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="hold_input" style="padding-top:75px;">
                                                <div class="box">
                                                    <label for=""><span>Email address</span></label><br>
                                                    <div class="content_input">
                                                        <input type="text" name="user_mail_d" id="" placeholder="email address" required> <i class="fa-solid fa-envelope-open"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="button_content">
                                                <button name="create_my_desktop_account">create my account</button>
                                            </div>
                                            
                                        </form>
                                        <div class="login_instead_button">
                                            <!-- content ends here -->
                                            <a href="#">Login instead</a>
                                            <!-- content  -->
                                        </div>
                                        <div class="uodown" style="display:<?php echo $_SESSION["display_user_exist_errot"];  ?>;">
                                            <div class="error">
                                                <span class="user_error" style="color:red;font-weight:bold;"><?php echo $_SESSION["user_exsit_error"]; ?></span>
                                            </div>
                                        </div>
                                        <!-- registration content ends here -->
                                    </div>
                                </div>





                                <div class="verifyer_area" style="display:<?php echo $_SESSION["show_verification_area"]; ?>;">
                                    <!-- to verify user account -->
                                    <div class="title_d" style=" line-height:15px;">
                                        <h2>validate your account
                                            <br><span style="font-weight:100; font-size:10px;">we have sent a verification code to <?php echo $_SESSION["user_email"]; ?></span>
                                        </h2>
                                    </div>

                                    <div class="reg_d" style="padding-top:1px;">
                                        <!-- registration content goes in here -->
                                        <form action="" method="post" autocomplete="off">
                                            <div class="hold_input">
                                                <div class="box">
                                                    <label for=""><span>verification code</span></label><br>
                                                    <div class="content_input">
                                                        <input type="number" name="user_code_d" id="" placeholder="verification code" required> <i class="fa-solid fa-code"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="hold_input" style="padding-top:75px;">
                                                <div class="box">
                                                    <label for=""><span>Account password</span></label><br>
                                                    <div class="content_input">
                                                        <input type="password" name="user_passcode_d" id="" placeholder="security code" required> <i class="fa-solid fa-lock"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="button_content">
                                                <button name="verify_my_account_on_desktop">verify my account</button>
                                            </div>
                                            
                                        </form>
                                        <div class="login_instead_button">
                                            <!-- content ends here -->
                                            <a href="#">why am i not getting my code ?</a>
                                            <!-- content  -->
                                        </div>
                                        <div class="uodown" style="display:<?php echo $_SESSION["display_user_exist_errot"];  ?>;">
                                            <div class="error">
                                                <span class="user_error" style="color:red;font-weight:bold;"><?php echo $_SESSION["user_exsit_error"]; ?></span>
                                            </div>
                                        </div>
                                        <!-- registration content ends here -->
                                    </div>


                                </div>





                                <div class="account_created_design_dialog" style="display:<?php echo $_SESSION["login_page_hide"];  ?>;">
                                    <div class="item">
                                        <p>Your account has been created</p>
                                        <p style="color:grey; font-size:13px;">Enter password to log you in</p>
                                    </div>

                                    <div class="reg_d" style="padding-left:60px;">
                                        <form action="" method="post" autocomplete="off">
                                            <div class="hold_input">
                                                <div class="box">
                                                    <label for=""><span>password to account <?php echo $_SESSION["signup_desktop_username"]; ?></span></label><br>
                                                    <div class="content_input">
                                                        <input type="password" name="mauel_password" id="" placeholder="password" required> <i class="fa-solid fa-code"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="button_content">
                                                <button name="login_user_manually">Login to account <?php echo $_SESSION["signup_desktop_username"]; ?></button>
                                            </div>
                                        </form>
                                        <div class="login_instead_button">
                                            <!-- content ends here -->
                                            <a href="#">Return back home?</a>
                                            <!-- content  -->
                                        </div>
                                        <div class="uodown" style="display:<?php echo $_SESSION["display_user_exist_errot"];  ?>;">
                                            <div class="error">
                                                <span class="user_error" style="color:red;font-weight:bold;"><?php echo $_SESSION["user_exsit_error"]; ?></span>
                                            </div>
                                        </div>
                                    </div>
                
                                </div>
            



                        </div>
                    </div>
                </center>
            
            </div>






            <div class="create_accounts" style="display:<?php echo $_SESSION["display_login_box"]; ?>;">
                <div class="mover">
                    <center>
                        <div class="display_vies">
                            <div class="close_icon">
                                    <form action="" method="post">
                                        <button name="close_user_account_box"><i class="fa-solid fa-xmark"></i></button>
                                    </form>
                            </div>

                            <div class="content_for_sign">
                                <div class="title_d">
                                    <h2>Login into account</h2>
                                </div>
                            </div>


                            <div class="reg_d" style="padding-left:60px;">
                                <form action="" method="post">
                                    <div class="hold_input">
                                        <div class="box">
                                            <label for=""><span>Username</span></label><br>
                                            <div class="content_input">
                                                <input type="text" name="login_username" id="" placeholder="username" required> <i class="fa-solid fa-user"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hold_input" style="padding-top:78px;">
                                        <div class="box">
                                            <label for=""><span>passord</span></label><br>
                                            <div class="content_input">
                                                <input type="password" name="password_password" id="" placeholder="password" required> <i class="fa-solid fa-lock"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="button_content">
                                        <button name="log_user_in">Login my account</button>
                                    </div>
                                </form>
                                <div class="login_instead_button">
                                    <!-- content ends here -->
                                    <a href="#">Return back home?</a>
                                    <!-- content  -->
                                </div>
                                <div class="uodown" style="display:<?php echo $_SESSION["display_user_exist_errot"];  ?>;">
                                    <div class="error">
                                        <span class="user_error" style="color:red;font-weight:bold;"><?php echo $_SESSION["user_exsit_error"]; ?></span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </center>
                </div>
            </div>













        </div>









     









































        













































            
    </div>



        








    
    <div class="pry" id="price">
        <div class="movers">
           <center>
                <div class="price_list">
                    <div class="close_menus">
                        <button id="close_price"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <div class="p_header">
                        <p>Pricing</p>
                        <span>Check out how our subscription plans works</span>
                    </div>

                    <div class="row_price">
                        <div class="column_price">
                            <span><b>Price</b></span>
                            <h1>100$</h1>
                            <div class="des">
                                <div class="valid">
                                    <span>Valid 1 year</span>
                                </div>
                            </div>
                        </div>

                        <div class="column_price">
                            <span><b>Price</b></span>
                            <h1>50$</h1>
                            <div class="des">
                                <div class="valid">
                                    <span>Valid half year</span>
                                </div>
                            </div>
                        </div>

                        <div class="column_price">
                            <span><b>Price</b></span>
                            <h1>30$</h1>
                            <div class="des">
                                <div class="valid">
                                    <span>Valid 1 month</span>
                                </div>
                            </div>
                        </div>


                        <div class="column_price">
                            <span><b>Price</b></span>
                            <h1>10$</h1>
                            <div class="des">
                                <div class="valid">
                                    <span>Valid 1 week</span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="advertisements" style="width:60%;">
                        <!-- this area display plane gif advertisement -->
                        <div class="ads_content">
                            <img src="asset/ads.gif" alt="">
                        </div>
                    </div>
                </div>
           </center>
        </div>
    </div>




    <div class="about_company" id="about_company">

        <center>
        <div class="moversss">
            <div class="aboout_contentes">
    
                <div class="close_menus">
                        <button id="close__about"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <div class="co">
                    <div class="contents">
                            <!-- content -->
                            <h4 class="suggest">About us</h4>
                            <p>
                                welcome to super prediction site, we offer our customers the best ways of getting predicted games
                                scores. we aid to get the best out as determine to develop an AI that automatically choose who will win
                                against two teams. Thank you foe willing to spend your time with us, and willing to use our service
                            </p>
                            <!-- content ends  -->
                        </div>


                        <div class="advertisements">
                            <!-- this area display plane gif advertisement -->
                            <div class="ads_content">
                                <img src="asset/ads.gif" alt="">
                            </div>
                        </div>



                        <div class="contents" style="padding-top:15px;">
                            <!-- content -->
                            <h4 class="suggest">How to play</h4>
                            <p>
                                We make the website easy and faster to let our customer understand the syntax easily, with the aid of the 
                                development we add created an to area ti view games that has already been redicted and played.. In other 
                                to check recently uploaded games, you need to create an account with our comoany, by clicking on the icon
                                at the top right corner of the header. after clicking on it, you need to then insert the following info 
                                ['username', 'gmail', 'phone number'], after that, you then varify your account. login into your account
                                a select a plan of subscription you wannt. make your payment, and they your games are ready to be viewed.
                            </p>
                            <!-- content ends  -->
                        </div>




                        <div class="advertisements">
                            <!-- this area display plane gif advertisement -->
                            <div class="ads_content">
                                <img src="asset/ads.gif" alt="">
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        </center>


    </div>




    <div class="feedback_area" id="send_feedbacls"> 
        <!-- content to send feedback -->
        <div class="mover_form">
           <center>
                <div class="forms">
                    <div class="close_menus">
                        <button id="close__feedback"><i class="fa-solid fa-xmark"></i></button>
                    </div>



                    <div class="title_bar">
                        <p>Send Us a FeedBack</p>
                    </div>


                   <form action="" method="post">
                        <div class="inputr">
                            <div class="name_input"><span><b>name</b></span></div><br>
                            <div class="input_main"><input type="text" name="name" id="" placeholder="your name" required></div>
                        </div>

                        <div class="inputr" style="padding-top:50px;">
                            <div class="name_input"><span><b>email address</b></span></div><br>
                            <div class="input_main"><input type="email" name="email_address" id="" placeholder="your email" required></div>
                        </div>

                        <div class="inputr" style="padding-top:50px;">
                            <div class="name_input"><span><b>Message</b></span></div><br>
                            <div class="input_main"><textarea name="" id="message" cols="30" rows="10" maxlength="200" required></textarea></div>
                        </div>
                        <div class="inputr">
                            <button name="send_feedback">send FeedBack</button>
                        </div>
                   </form>


                </div>
           </center>
        </div>
    </div>
    




    <div class="contact_us_box_menus" id="contadjd"> 
        <!-- content -->
        <div class="movern_contact">
            <center>
                <div class="container_contact">
                    <!-- contact goes in here -->
                    <div class="close_menus">
                        <button id="close__contactk"><i class="fa-solid fa-xmark"></i></button>
                    </div>

                    <p>Contact us</p>
                    <div class="link">
                        <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
            </center>
        </div>
    </div>


               
    <div class="learn_how_to" id="learns">
        <!-- content, to leatn how to predict -->
        <center>
            <div class="le_mover">
                <div class="learn_box">
                    <div class="close_menus">
                        <button id="close_learns"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <div class="video_odg" style="padding-top:20px;">
                        <iframe width="700" height="410" src="https://www.youtube.com/embed/qj8YxywUaNc" title="How to WIN BET Daily : Make Huge money Everyday BET, $700 USD every week, SPORTYBET Tips,BETWAY Tips" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </center>
        <!-- how to predict ends here -->
    </div>







































        <!-- content of desktop ends here -->
    </div>





































































































































































    
    
    <!-- mobile views -->
    <div class="mobile_views" id="mobile_views">
        <!-- content of mobile views start here -->


        <!-- loading screen -->
        <div class="loading_screen" id="loading_screen">
            <!-- content -->
            <!-- under the css properties of mobie/loadingscreen.css -->
            <!-- content ends here -->
        </div>
        <!-- loading screen ends here -->









        <!-- under the css properties of mobie/loadingscreen.css -->
        <div class="full_screen" style="display:none;">
            <!-- this area shows full screen advertisement -->
            <div class="video_advertisement">

                <div class="title">
                    <span>Sponsored ads</span><br>
                    <span>please wait for 6seconds</span>
                </div>

                <!-- <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6191129164571975"
                    crossorigin="anonymous"></script>
                <ins class="adsbygoogle"
                    style="display:block"
                    data-ad-client="ca-pub-6191129164571975"
                    data-ad-slot="7225910750"
                    data-ad-format="auto"
                    data-full-width-responsive="true"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script> -->
            </div>

        </div>

















































        <!-- under the css properties of header.css -->
        <div class="header">
            <!-- content header start here -->
           <div class="layout_one">
                <div class="left_content">
                    <h2>Bestodds<span style="color:tomato;">station</span></h2>
                </div>
                <div class="right_content">
                    <button class="extends" id="create_account"><i class="fa-solid fa-user"></i></button>
                    <button id="open_drop_show"><i class="fa-solid fa-bars"></i></button>
                </div>
           </div>
           <div class="layout_two">
               <!-- content start -->
               <center>
                <a href="#" target="_SELF" class="active" id="menu_oner"><i class="fa-solid fa-house"></i> Home</a>
                <a href="#" target="_SELF" id="menu_twor"><i class="fa-solid fa-circle-check"></i> About us</a>
                <a href="#" target="_SELF" id="menu_threer" ><i class="fa-solid fa-tags"></i> pricings</a>
                <a href="#" target="_SELF" id="menu_fourr"><i class="fa-solid fa-futbol"></i> other sports</a>
               </center>
               <!-- content ends here -->
           </div>
            <!-- content header ends here -->
        </div>





        <div class="drop_down_menus" id="drop_bnt">   
                <div class="drop_contents">
                    <center>
                        <a href="#" id="football">FootBall</a>
                        <a href="#" id="america_football">America FootBall</a>
                        <a href="#" id="close_bnt">close</a>
                    </center>
                </div>
        </div>

    





        <div class="viewers_content" id="football_views">



            <!-- content of view pages -->
            <!-- under the css properties of mobile/content.css -->
            <div class="landing_page">
               <div class="contentsrs">
                    <center>
                        <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                        <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                    </center>
               </div>
            </div>




            <!-- this area is for menus -->
            <!-- under the css properties of mobile/content.css -->
            <div class="menus">
                <!-- content goes in here-->
                <center>
                    <button class="activesers" id="butsr"><i class="fa-solid fa-list"></i> Football</button>
                    <button id="butssr"><i class="fa-solid fa-money-bills"></i> near</button>
                    <button id="butsssr"><i class="fa-solid fa-heart"></i> How to</button>
                    <button id="butssssr"><i class="fa-solid fa-heart"></i> type</button>
                </center>
                <!-- content ends here -->
            </div>







            <div class="advertisements">
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="asset/ads.gif" alt="">
                </div>
            </div>






            <!-- 
                this is the content holding the matches already playes
            -->


            <div class="content_holder" id="finished_games">
                <!-- we are creating a role that handles coloumb -->
                <!-- under the css properties of mobile/content_holder.css -->

                <div class="safe_area">
                    <!-- content start here -->
                    <div class="row">
                        <!-- to handle the columb -->
                        <?php 
                            // .. we want to fetch data for real matches
                            $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM current_life_matchaes order by id desc");
                            while($data = mysqli_fetch_assoc($fecth_real_datas)){
                        ?>
                        <div class="column">
                           
                            <div class="layer_one">
                                <div class="the_teams">
                                    <style>
                                        .the_teams span{
                                            font-size:10px;
                                        }
                                    </style>
                                    <!-- team a -->
                                    <span style="font-size:11px; color:grey"><?php echo $data["time"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                    <span><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $data["team_a_country"]; ?> "></span> <span><b><?php  echo $data["team_a_name"]; ?> </b></span></span>
                                    <!-- conpetition text -->
                                    <span style="color:tomato;">vs</span>
                                    <!-- team a -->
                                    <span><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $data["team_b_country"]; ?> "></span> <b><?php  echo $data["team_b_name"]; ?> </b></span>
                                </div>
                            </div>
                            <!-- breaks -->
                           
                            <!-- break -->
                            <div class="layout_four">
                                <!-- showing if ender or started -->
                                <form action="" method="post">
                                <input type="hidden" name="game_code" value="<?php echo $data["random_code"]; ?>">
                                <div class="sign" id="blinkIcon"><span><button name="check" onclick="show_selection()" style="width:55px; background-color:red;">check</button></span></div>
                                </form>
                            </div>
                            <!-- break line -->
                            <div class="layer_three">
                                <!-- showing time the game ended
                                <span style="color:lightgreen">12:40 pm</span> -->
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_a_percentage"] ?>)</span>
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_b_percentage"]; ?>)</span>
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                    <!-- content ends here -->
                </div>

                
                <center>
                <div class="selected_game" id="selected_game" style="display:<?php echo $_SESSION["hide_select"]; ?>;">
                <!-- content to show selected games -->
                <!-- we are creating a role that handles coloumb -->
                <!-- under the css properties of mobile/content_holder.css -->

                <?php 
                    // getting user values
                    $user_values = $_SESSION["user_select"];
                    $select = mysqli_query($connect_db, "SELECT * FROM current_life_matchaes WHERE random_code='$user_values'");
                    while($selecter = mysqli_fetch_assoc($select)){
                ?>

                <div class="movwe">
                    <div class="box_select">
                        <!-- content start-->
                        <div class="move_left">
                            <a href="" name="subscject"><i class="fa-solid fa-rectangle-xmark" onclick="close_selecte()"></i></a>
                        </div>



                        <div class="team_display">
                            <!-- team display start -->
                            <div class="l">
                                <center><span style="font-size:12px;"><?php  echo $selecter["team_a_percentage"]; ?>%</span></center>
                                <div class="county"><span class="flag-icon flag-icon-<?php  echo $selecter["team_a_country"] ?>"></span>
                                <br><center><span style="font-size:10px;"><?php  echo $selecter["team_a_name"]; ?></span></center>
                            </div>
                            </div>
                            <div class="score_o">
                                <!-- teams score-->
                                <span id="team_a_score"><?php  echo $selecter["team_a_score"] ?></span>
                                <!-- dash(seprator) -->
                                <span><i class="fa-solid fa-minus"></i></span>
                                <!-- team b score -->
                                <span id="team_b_score"><?php  echo $selecter["team_b_scroe"] ?></span>
                            </div>
                            <div class="r">
                                <center><span style="font-size:12px;"><?php  echo $selecter["team_b_percentage"] ?>%</span></center>
                                <div class="county"><span class="flag-icon flag-icon-<?php  echo $selecter["team_b_country"] ?>"></span> 
                                <br><center><span style="font-size:10px;"><?php  echo $selecter["team_b_name"]; ?></span></center>
                            </div>
                            </div>
                            <!-- team display ends -->
                        </div>


                        <!-- <div class="sharebuttons">
                            <center>
                                <a href="#"><i class="fa-brands fa-linkedin"></i></a>
                                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                            </center>
                        </div> -->


                        <!-- content end -->
                    </div>
                </div>
                <?php   
                    
                    }
                ?>
                </div>
                </center>

            </div>





















            <!-- this area is for near games -->
            <!-- it display games that are going to be playing next -->
            <!-- 
                it display the time the game will be played
                it display the two team that will be playing
            -->

            <!-- under the css properties of {{near_games_mobile.css}} -->
            <div class="near_upcoming_games" id="upcoming_matches" style="padding-top:33px;">
                <!-- the ui of the games -->
                <div class="row_near">
                    <!-- fetch game datas -->
                    <?php 
                        $fetch_near_games = mysqli_query($connect_db, "SELECT * FROM upcoming_games_management order by id desc");
                        while($near = mysqli_fetch_assoc($fetch_near_games)){
                    ?>
                    <div class="column_near">
                        <div class="ui_title">
                            <span><i class="fa-solid fa-baseball"></i> <?php echo $near["title"]; ?> </span>
                        </div>
                        <div class="ui_box">
                            <div class="ui_contents">
                                <div class="ui_content_one">
                                    <div class="ui_left">
                                        <div class="the_teams">
                                            <div class="team_a"><span><span class="flag-icon flag-icon-<?php echo $near["team_a_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_a_name"]; ?></span> </span></div>
                                            <div class="competitor_sign"><span><center>vs</center></span></div>
                                            <div class="team_B"><span><span class="flag-icon flag-icon-<?php echo $near["team_b_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_b_name"]; ?></span> </span></div>
                                        </div>
                                    </div>
                                    <div class="ui_right">
                                        <i class="fa-solid fa-award"></i>
                                    </div>
                                </div>


                                <div class="nn">
                                    <div class="ui_content_two">
                                        <div class="u_left">
                                            <div class="timer_S">
                                                <span style="color:green;">Time : </span>
                                                <span><?php echo $near["months"]; ?></span>
                                            </div>
                                        </div>

                                        <div class="u_right">
                                            <span><?php echo $near["timess"]; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php 
                        }
                    ?>
                </div>
            </div>










            


            <div class="how_to_play" style="display:none; padding-top:30px;" id="learn_how_to">
                <!-- this shows a video users do...... -->
                <div class="content_holder">
                    <!-- content ends here -->
                    <center>
                    <iframe width="370" height="200" src="https://www.youtube.com/embed/xR_Ze3uinxc" title=""I Tried To Warn You" — Elon Musk's Last WARNING & Recession Prediction (2022)" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </center>
                    <!-- content start here -->
                </div>
            </div>




            
            <div class="advertisements">
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="asset/ads.gif" alt="">
                </div>
            </div>



            <!-- content of viewers_content  ends here -->
        </div>


























        <div class="american_football" id="america_footer_view">
                    
            <!-- content of view pages -->
            <!-- under the css properties of mobile/content.css -->
            <div class="landing_page">
               <div class="contentsrs">
                    <center>
                        <h2>super<span style="color:tomato;">bet</span> Predict and win over <span style="color:lightgreen;">7,500+</span> gamees</h2>
                        <span>Gamble Responsibily. Terms & condition apply. <span style="color:tomato;">18+</span></span>
                    </center>
               </div>
            </div>




            <!-- this area is for menus -->
            <!-- under the css properties of mobile/content.css -->
            <div class="menus_america">
                <!-- content goes in here-->
                <center>
                    <button class="activesers" id="butsrs">American Football</button>
                    <button id="butssrs"><i class="fa-solid fa-money-bills"></i> Upcoming</button>
                    <button id="butssssrs"><i class="fa-solid fa-heart"></i> How to</button>
                </center>
                <!-- content ends here -->
            </div>

            <div class="advertisements">
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="asset/ads.gif" alt="">
                </div>
            </div>



            <div class="content_holders">
                <div class="safe_area" id="live_matchaed">
                    <!-- content start here -->
                    <div class="row">
                        <!-- to handle the columb -->
                        <?php 
                            // .. we want to fetch data for real matches
                            $fecth_real_datas = mysqli_query($connect_db, "SELECT * FROM live_american_matched order by id desc");
                            while($data = mysqli_fetch_assoc($fecth_real_datas)){
                        ?>
                        <div class="column">
                           
                            <div class="layer_one">
                                <div class="the_teams">
                                    <!-- team a -->
                                    <span style="font-size:11px; color:grey"><?php echo $data["timeer"]; ?> <i class="fa-solid fa-clock"></i></span><br><br>
                                    <span><span id="country_one"><span class="flag-icon flag-icon-<?php  echo $data["team_a_country"]; ?> "></span> <b><?php  echo $data["team_a_name"]; ?> </b></span>
                                    <!-- conpetition text -->
                                    <span style="color:tomato;">vs</span>
                                    <!-- team a -->
                                    <span><span id="country_two"><span class="flag-icon flag-icon-<?php  echo $data["team_b_country"]; ?> "></span> <b><?php  echo $data["team_b_name"]; ?> </b></span>
                                </div>
                            </div>
                            <!-- breaks --> 
                          
                            <!-- break -->
                            <div class="layout_four">
                                <!-- showing if ender or started -->
                                <form action="" method="post">
                                <input type="hidden" name="game_code" value="<?php echo $data["random_code"]; ?>">
                                <div class="sign" id="blinkIcon"><span><button style="width:55px; background-color:red;">played</button></span></div>
                                </form>
                            </div>
                            <!-- break line -->
                            <div class="layer_three">
                                <!-- showing time the game ended
                                <span style="color:lightgreen">12:40 pm</span> -->
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_a_percentage"] ?>)</span>
                                <span style="color:lightgreen;">fx.(<?php  echo $data["team_b_percentage"]; ?>)</span>
                            </div>
                            <div class="layer_one" style="float:right;padding-right:7px; padding-top:16px;">
                               (<span>1</span>
                               <span>-</span>
                               <span>0</span>)
                           </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                    <!-- content ends here -->
                </div>





                <div class="near_upcoming_games" id="upcoming_america_football" style="padding-top:33px;">
                    <!-- the ui of the games -->
                    <div class="row_near">
                        <!-- fetch game datas -->
                        <?php 
                            $fetch_near_games = mysqli_query($connect_db, "SELECT * FROM upcoming_games_management order by id desc");
                            while($near = mysqli_fetch_assoc($fetch_near_games)){
                        ?>
                        <div class="column_near">
                            <div class="ui_title">
                                <span><i class="fa-solid fa-baseball"></i> <?php echo $near["title"]; ?> </span>
                            </div>
                            <div class="ui_box">
                                <div class="ui_contents">
                                    <div class="ui_content_one">
                                        <div class="ui_left">
                                            <div class="the_teams">
                                                <div class="team_a"><span><span class="flag-icon flag-icon-<?php echo $near["team_a_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_a_name"]; ?></span> </span></div>
                                                <div class="competitor_sign"><span><center>vs</center></span></div>
                                                <div class="team_B"><span><span class="flag-icon flag-icon-<?php echo $near["team_b_country"]; ?>" style="font-size:20px;"></span> <span><?php echo $near["team_b_name"]; ?></span> </span></div>
                                            </div>
                                        </div>
                                        <div class="ui_right">
                                            <i class="fa-solid fa-award"></i>
                                        </div>
                                    </div>


                                    <div class="nn">
                                        <div class="ui_content_two">
                                            <div class="u_left">
                                                <div class="timer_S">
                                                    <span style="color:green;">Time : </span>
                                                    <span><?php echo $near["months"]; ?></span>
                                                </div>
                                            </div>

                                            <div class="u_right">
                                                <span><?php echo $near["timess"]; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php 
                            }
                        ?>
                    </div>
                </div>






                <div class="how_to_play" style="display:none; padding-top:30px;" id="learn_america">
                    <!-- this shows a video users do...... -->
                    <div class="content_holder">
                        <!-- content ends here -->
                        <center>
                        <iframe width="370" height="200" src="https://www.youtube.com/embed/xR_Ze3uinxc" title=""I Tried To Warn You" — Elon Musk's Last WARNING & Recession Prediction (2022)" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </center>
                        <!-- content start here -->
                    </div>
                </div>




            </div>




            <div class="advertisements" >
                <!-- this area display plane gif advertisement -->
                <div class="ads_content">
                    <img src="asset/ads.gif" alt="">
                </div>
            </div>


        </div>






























        <!-- the footer content goes in here, -->
        <!-- footer to help user navigate easily around the screen -->
        <!-- under the css properties of footer.css -->
        <div class="safe_guard">
            <div class="footer_mobile">
                <!-- content goes in here -->
                <div class="footer_title">
                    <h2>Super<span style="color:tomato;">Bet</span></h2>
                </div>
                <!-- menu handler -->
                <center>
                <div class="row_two">
                    <!-- column handleer -->
                   
                    <div class="wrap_a">
                        <div class="column_two">
                            <div class="title_bar_one">
                                <p style="color:grey; font-size:15px;">superbet.com</p>
                                <a href="#" onclick="openabout_us()">Contact us</a>
                                <a href="../homepage/viewer_page.php">Home</a>
                                <a href="#" onclick="terms_of_user()">Terms of use</a>
                            </div>
                        </div>  


                        <div class="column_two">
                            <div class="title_bar_three">
                                <p style="color:grey; font-size:15px;">Follow us on</p>
                                <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                            </div>
                        </div>  
                    </div>


                    <div class="wrap_b">
                        <div class="column_two">
                            <div class="title_bar_two">
                                <p style="color:grey; font-size:15px;">Send Regards</p>
                                <a href="#" id="about_us_one">About Us</a>
                                <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                            </div>
                        </div>  

                        <div class="column_two">
                            <div class="title_bar_four">
                                <p style="color:grey; font-size:15px;">Download</p>
                                <a href="#">App store</a>
                                <a href="#">playstore</a>
                                <a href="#">cloud store</a>
                            </div>
                        </div>  
                    </div>



                </div>
                </center>
                <!-- content ends here -->
            </div>  
        </div>





































































































        <!-- those are the signup pages -->



        <!-- 

            => under the css properties of registrationpage.css
            => this get user datas such as ['username', 'email','phone number']
            => after gettig the user informations then pass the data to the database
            => after that open a varification page to pass the opt code into the database


            => the login page involves
            => ['username', 'password']
            => After login in you have to pay for monthly subscriptions
            => if you account has already been subscribed already then login users
            => else
            => Dont log user in

         -->

        <div class="registration_page" style="display:none;" id="reg_views">
            <!-- conntent of registrations pages goes in here -->
            <div class="container_mover">
                <!-- content -->
                <div class="container_box_designs" id="all_page_Reg">

                    <div class="drop_down_icons">
                        <!-- <center>
                            <div class="icons_dash" id="icon_dash"></div>
                        </center> -->
                    </div>




                    <div class="title_bar" id="signup_title">
                        <!-- title goes in here -->
                        <!-- <div class="title">
                            <center>
                                <p style="color:gray; font-size:22px;">Create an account</p>
                            </center>
                        </div> -->
                    </div>


                    <div class="title_bar" id="login_title" style="display:none;">
                        <!-- title goes in here -->
                        <!-- <div class="title">
                            <center>
                                <p style="color:gray; font-size:22px;">Signin your account</p>
                            </center>
                        </div> -->
                    </div>



                    <!-- 
                        this area is for the sign up place asking for the signup place 

                     -->

                    <div class="registration_viees" id="signup">
                        <!-- content goes in here -->
                        <!-- 
                            => asking user for there informations
                         -->
                         <form action="" method="POST">
                            <span style="
                                padding:10px;
                                border:none;
                                background-color:whitesmoke;
                                border-radius:4px;
                                color:darkblue;
                            ">Create an account</span>
                            <div class="holder" style="padding-top:15px;">
                                <div class="informations">
                                    <span>username</span><br>
                                    <input type="text" placeholder="Enter your username" required name="username"><i class="fa-solid fa-user"></i>
                                </div>
                            </div>
                            <!-- line breaks -->
                            <div class="holder">
                                <div class="informations">
                                    <span>email address</span><br>
                                    <input type="email" placeholder="insert your email address" required name="email"><i class="fa-solid fa-envelope-open"></i>
                                </div>
                            </div>
                             <!-- line breaks -->
                            <div class="holder">
                                <div class="informations">
                                    <span>phone number</span><br>
                                    <input type="number" placeholder="Enter your phone number" required name="phoneno"><i class="fa-solid fa-phone-flip"></i>
                                </div>
                            </div>
                            <div class="signupbutton">
                                <button name="create_my_account">create my account</button>
                            </div>
                         </form>

                         <!-- login instead button -->
                         <div class="login_instead">
                             <center><a href="#" id="signin">sign in instead</a></center>
                         </div>

                         <div class="advertisements">
                            <!-- this area display plane gif advertisement -->
                            <div class="ads_content" style="width:90%;">
                                <img src="asset/ads.gif" alt="">
                            </div>
                        </div>
                    </div>


                    <!-- 
                        => this area is for login place
                        => asking for the the listed informations
                        [
                            'username'
                            'passowrd'
                        ]
                     -->

                    <div class="registration_viees" style="display:none;" id="login">
                        <!-- content goes in here -->
                        <!-- 
                            => asking user for there informations
                         -->
                         <form action="" method="POST">
                            <span style="
                                padding:10px;
                                border:none;
                                background-color:whitesmoke;
                                border-radius:4px;
                                color:darkblue;
                            ">Login into your account</span>
                            <div class="holder" style="padding-top:15px;">
                                <div class="informations">
                                    <span>username</span><br>
                                    <input type="text" placeholder="Enter your username" required name="userlogin"><i class="fa-solid fa-user"></i>
                                </div>
                            </div>
                            <!-- line breaks -->
                            <div class="holder">
                                <div class="informations">
                                    <span>password</span><br>
                                    <input type="password" placeholder="Insert your security code" required name="userpasscode" style="text-transform: none;"><i class="fa-solid fa-lock"></i>
                                </div>
                            </div>
                             <!-- line breaks -->
                            <div class="signupbutton">
                                <button name="logmein_my_account">Log me in</button>
                            </div>
                         </form>

                         <!-- login instead button -->
                         <div class="login_instead">
                             <center><a href="#" id="create_account_instead">create an account</a></center>
                         </div>

                        <div class="advertisements">
                            <!-- this area display plane gif advertisement -->
                            <div class="ads_content" style="width:90%;">
                                <img src="asset/ads.gif" alt="">
                            </div>
                        </div>
                    </div>



                </div>
            </div>

                    <!-- the footer content goes in here, -->
                <!-- footer to help user navigate easily around the screen -->
                <!-- under the css properties of footer.css -->
                <div class="safe_guard">
                    <div class="footer_mobile">
                        <!-- content goes in here -->
                        <div class="footer_title">
                            <h2>Super<span style="color:tomato;">Bet</span></h2>
                        </div>
                        <!-- menu handler -->
                        <center>
                        <div class="row_two">
                            <!-- column handleer -->
                        
                            <div class="wrap_a">
                                <div class="column_two">
                                    <div class="title_bar_one">
                                        <p style="color:grey; font-size:15px;">superbet.com</p>
                                        <a href="#" onclick="openabout_us()">Contact us</a>
                                        <a href="../homepage/viewer_page.php">Home</a>
                                        <a href="#" onclick="terms_of_user()">Terms of use</a>
                                    </div>
                                </div>  


                                <div class="column_two">
                                    <div class="title_bar_three">
                                        <p style="color:grey; font-size:15px;">Follow us on</p>
                                        <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                        <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                        <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                        <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                    </div>
                                </div>  
                            </div>


                            <div class="wrap_b">
                                <div class="column_two">
                                    <div class="title_bar_two">
                                        <p style="color:grey; font-size:15px;">Send Regards</p>
                                        <a href="#" id="aboutus_two">About Us</a>
                                        <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                    </div>
                                </div>  

                                <div class="column_two">
                                    <div class="title_bar_four">
                                        <p style="color:grey; font-size:15px;">Download</p>
                                        <a href="#">App store</a>
                                        <a href="#">playstore</a>
                                        <a href="#">cloud store</a>
                                    </div>
                                </div>  
                            </div>



                        </div>
                        </center>
                        <!-- content ends here -->
                    </div>  
                </div>

            <!-- content of registrations pages ends here -->
        </div>










    

























        <!-- 
            about us area displays over here
            the about us area

            Under the css properties of about us........   {{ aboutus.css }}

         -->
         <div class="aboutus" style="display:none;" id="aboutus">
            <!-- content of about us start here -->


            <div class="aboout_content">

                <div class="welcome_svg">
                    <center>
                    <img src="asset/welcome.svg" alt="">
                    </center>
                </div>


                <div class="contents">
                    <!-- content -->
                    <h4 class="suggest">About us</h4>
                    <p>
                        welcome to super prediction site, we offer our customers the best ways of getting predicted games
                        scores. we aid to get the best out as determine to develop an AI that automatically choose who will win
                        against two teams. Thank you foe willing to spend your time with us, and willing to use our service
                    </p>
                    <!-- content ends  -->
                </div>


                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="asset/ads.gif" alt="">
                    </div>
                </div>



                <div class="contents" style="padding-top:15px;">
                    <!-- content -->
                    <h4 class="suggest">How to play</h4>
                    <p>
                        We make the website easy and faster to let our customer understand the syntax easily, with the aid of the 
                        development we add created an to area ti view games that has already been redicted and played.. In other 
                        to check recently uploaded games, you need to create an account with our comoany, by clicking on the icon
                        at the top right corner of the header. after clicking on it, you need to then insert the following info 
                        ['username', 'gmail', 'phone number'], after that, you then varify your account. login into your account
                        a select a plan of subscription you wannt. make your payment, and they your games are ready to be viewed.
                    </p>
                    <!-- content ends  -->
                </div>




                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="asset/ads.gif" alt="">
                    </div>
                </div>



            </div>


            <!-- the footer content goes in here, -->
            <!-- footer to help user navigate easily around the screen -->
            <!-- under the css properties of footer.css -->
            <div class="safe_guard">
                <div class="footer_mobile">
                    <!-- content goes in here -->
                    <div class="footer_title">
                        <h2>Super<span style="color:tomato;">Bet</span></h2>
                    </div>
                    <!-- menu handler -->
                    <center>
                    <div class="row_two">
                        <!-- column handleer -->
                    
                        <div class="wrap_a">
                            <div class="column_two">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" onclick="openabout_us()">Contact us</a>
                                    <a href="../homepage/viewer_page.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>  


                            <div class="column_two">
                                <div class="title_bar_three">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>  
                        </div>


                        <div class="wrap_b">
                            <div class="column_two">
                                <div class="title_bar_two">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_us_one">About Us</a>
                                    <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                </div>
                            </div>  

                            <div class="column_two">
                                <div class="title_bar_four">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>  
                        </div>



                    </div>
                    </center>
                    <!-- content ends here -->
                </div>  
            </div>



            <!-- content of about us ends here -->
         </div>


























        <!-- This shows the informations about pricing and payment methods -->
        <!-- under the css property of {{ pricing_m.css }} -->
        <div class="pricing_area" id="pricing_area">

            <!-- content of pricing starting -->
            <div class="price_content_holder">
                <!-- <div class="payment_img">
                    <center>
                        <img src="../asset/pay.svg" alt="" srcset="">
                    </center>
                </div> -->


                <div class="contents">
                    <!-- content -->
                    <h4 class="suggest">Subscribing to your account</h4>
                    <p>
                        Firstly, you need to create an account, after your account creationg verify your account with the verification
                        code sent to your email, after verification navigate back home, and login into your account again, once you are login
                        an area, to select prefered price will be poped up, select your prefer subscription plan, and insert your password to
                        clearify you are the rightfull owner of the account. AFter the steps listed. Check out your subscription and pay using 
                        any transaction cards. Thank you
                    </p>
                    <!-- content ends  -->
                </div>


                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="asset/ads.gif" alt="">
                    </div>
                </div>





                <div class="contents" style="padding-top:15px;">
                    <!-- content -->
                    <div class="titt">
                        <h2 class="suggest">Pricing List</h2>
                    </div>


                    <div class="row_p">
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>100$</h2>
                                <span class="display"> Valid 1 year </span>
                            </center>
                        </div>
                        <!-- breaks -->
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>50$</h2>
                                <span class="display"> Valid half A year </span>
                            </center>
                        </div>

                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>30$</h2>
                                <span class="display"> Valid 1 month </span>
                            </center>
                        </div>
                        <!-- breaks -->
                        <div class="column_p">
                            <center>
                                <!-- price -->
                                <h2>10$</h2>
                                <span class="display"> Valid 1 week </span>
                            </center>
                        </div>
                    </div>
                    <!-- content ends   -->
                </div>



                <div class="advertisements">
                    <!-- this area display plane gif advertisement -->
                    <div class="ads_content">
                        <img src="asset/ads.gif" alt="">
                    </div>
                </div>



                


            </div>


             <!-- the footer content goes in here, -->
            <!-- footer to help user navigate easily around the screen -->
            <!-- under the css properties of footer.css -->
            <div class="safe_guard">
                <div class="footer_mobile">
                    <!-- content goes in here -->
                    <div class="footer_title">
                        <h2>Super<span style="color:tomato;">Bet</span></h2>
                    </div>
                    <!-- menu handler -->
                    <center>
                    <div class="row_two">
                        <!-- column handleer -->
                    
                        <div class="wrap_a">
                            <div class="column_two">
                                <div class="title_bar_one">
                                    <p style="color:grey; font-size:15px;">superbet.com</p>
                                    <a href="#" onclick="openabout_us()">Contact us</a>
                                    <a href="../homepage/viewer_page.php">Home</a>
                                    <a href="#" onclick="terms_of_user()">Terms of use</a>
                                </div>
                            </div>  


                            <div class="column_two">
                                <div class="title_bar_three">
                                    <p style="color:grey; font-size:15px;">Follow us on</p>
                                    <a href="#"><i class="fa-brands fa-linkedin"></i> LinkEdIn</a>
                                    <a href="#"><i class="fa-brands fa-twitter"></i> twitter</a>
                                    <a href="#"><i class="fa-brands fa-instagram"></i> Instargram</a>
                                    <a href="#"><i class="fa-brands fa-facebook"></i> facebook</a>
                                </div>
                            </div>  
                        </div>


                        <div class="wrap_b">
                            <div class="column_two">
                                <div class="title_bar_two">
                                    <p style="color:grey; font-size:15px;">Send Regards</p>
                                    <a href="#" id="about_us_three">About Us</a>
                                    <a href="#"  onclick="sendfeedback()">FeedBacks</a>
                                </div>
                            </div>  

                            <div class="column_two">
                                <div class="title_bar_four">
                                    <p style="color:grey; font-size:15px;">Download</p>
                                    <a href="#">App store</a>
                                    <a href="#">playstore</a>
                                    <a href="#">cloud store</a>
                                </div>
                            </div>  
                        </div>



                    </div>
                    </center>
                    <!-- content ends here -->
                </div>  
            </div>





            <!-- content of pricing ends here -->

        </div>












        

        <!-- unde the css properties of contactus.css -->
        <div class="contact_us" id="contactus" onClick="close()">
            <!-- conact us content -->
            <div class="contact_mover">
                <center>
                <div class="conact_box">
                    <!-- content -->    
                    <center><p>Contact <span style="color:red;">us</span></p></center>
                    <!-- content ends here -->


                    <!-- all media links -->
                    <div class="links">
                        <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
                </center>
            </div>
            <!-- contact us content ends here -->
        </div>




       










        <!-- unde the css properties of contactus.css -->     
        <div class="terms_of_user" id="terms_of_user">
            <div class="terms_mover">
               <center>
                    <div class="content_terms">
                            <p><b>Terms of <span style="color:red;">user</span></b></p>

                            <p>
                                The website is restricted, for individuals below 18, only <span style="color:red;">18+</span> are 
                                allowed. Thank you
                            </p>

                            <button id="close_terms">ok</button>
                    </div>
               </center>
            </div>
        </div>













        <!-- feed backs -->
        <!-- unde the css properties of contactus.css -->  
        <center>
        <div class="feedbacks" id="sendfeedback">
            <div class="feedback_mover">
                <div class="feedback_content">
                        <center>
                            <p>Send Feed<span style="color:red;">backs</span></p>
                        </center>


                        <div class="regs">
                            <!-- forms -->
                            <form action="" method="post">
                               <div class="topper">
                                    <label for="">
                                        <span>your name</span><br>
                                        <input type="text" name="name" id="" placeholder="Tell us your name" required>
                                    </label>
                               </div>
                               <div class="topper">
                                    <label for="">
                                        <span>your email address</span><br>
                                        <input type="email" name="email_address" id="" placeholder="Tell us your name" required>
                                    </label>
                               </div>
                               <div class="topper">
                                    <label for="">
                                        <span>your name</span><br>
                                        <textarea name="message" id="" cols="30" rows="10" required></textarea>
                                    </label>
                               </div>
                               <div class="topper">
                                  <button name="send_feedback">send feedback</button>
                               </div>
                            </form>
                            <div class="topper">
                                  <button class="closebtn" id="closebtn">close</button>
                               </div>

                        </div>

                </div>
            </div>
        </div>
        </center>
        









          <!-- this area is use for login place -->
        <!-- unde the css properties of contactus.css -->  
        <center>
        <div class="login" id="sendfeedback" style="display:<?php echo $_SESSION["user_login_box"]; ?>;">
            <div class="login_mover">
                <div class="login_content">
                        <center>
                            <p>Login <span style="color:red;">into</span> your account</p>
                        </center>


                        <div class="regs">
                            <!-- forms -->
                            <form action="" method="post">
                               <div class="toppers">
                                    <label for="">
                                        <span>Username</span><br>
                                        <input type="text" name="userlogin" id="" placeholder="Enter your account username">
                                    </label>
                               </div>
                               <div class="toppers">
                                    <label for="">
                                        <span>password</span><br>
                                        <input type="password" name="userpasscode" id="" placeholder="Enter your account password">
                                    </label>
                               </div>

                               <div class="toppers">
                                    <button name="logmein_my_account">Login to my account</button>
                               </div>
                            </form>
                            <div class="toppers">
                                    <form action="" method="post">
                                        <button class="closebtn" id="closebtn" name="closesession">close</button>
                                    </form>
                               </div>

                        </div>

                </div>
            </div>
        </div>
        </center>
        



















        <!-- content of mobile views ends here -->
    </div>
</body>
</html>

<!-- responsiveness link goes here -->
<div class="linkings">
    <link rel="stylesheet" href="customizations/responsiveness/homepage_responsiveness.css">
</div>