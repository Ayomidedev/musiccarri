<?php 
    session_start();
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,  user-scalable=0">
    <title>done</title>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
     <!--icon-->
     <script src="https://kit.fontawesome.com/65018229a0.js" crossorigin="anonymous"></script>
    <!-- jquery connenction -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <link rel="stylesheet" href="customizations/done/mobile/content.css">
    <link rel="stylesheet" href="customizations/done/mobile/varifyer.css">   
    <link rel="stylesheet" href="customizations/homepage/mobile/footer.css">


    <div class="hidden_file" style="display:none;">
        <!-- link to php -->
        <?php
            require("backend/homepage/verification_script.php");
        ?>
    </div>
</head>
<body>



    <div class="desktop_views">

    </div>



    <div class="mobile_views">
        <!-- content start here -->
        <div class="holder_top">
            <!-- content -->
            <div class="dp" id="dp">
            <center>
            <img src="../asset/load-unscreen.gif" alt="">
            </center>
            </div>

            <div class="title" id="title" style="display:none;">
               <center>
                <p>Account created</p>
                <button id="click_button">verify account</button>
               </center>
            </div>
        </div>
        <!-- content ends here -->



        <!-- under the css properties of varifyer.css -->
        <div class="varifyer_page" id="veri_page" style="display:none;">
            <!-- content goes in here -->
            <div class="box_container">


                <div class="header_icon">
                    <i class="fa-solid fa-circle-chevron-left" onclick="naviagateback()"></i>
                </div>

                <script>
                    function naviagateback(){
                        window.history.back();
                    }
                </script>


                <div class="title_bar">
                    <!-- tiel goes in her e-->
                    <center>
                        <p style="color:grey; font-size:19px;">welcome, <span><b><?php echo $_SESSION["new_account_storage"]; ?></b></span></p>
                        <span style="color:grey;">let get your account verified</span>
                    </center>
                </div>




                <center>
                    <div class="cncn">
                        <div class="reg_menus" style="float:left;">
                            <form action="" method="POST">
                                <div class="holder">
                                    <div class="informations">
                                        <span>Verification code</span><br>
                                        <input type="number" placeholder="Enter the opt code sent to your mail" required name="opt_code"><i class="fa-solid fa-user"></i>
                                    </div>
                                </div>
                                <div class="holder">
                                    <div class="informations">
                                        <span>password</span><br>
                                        <input type="password" placeholder="create a new password" required name="passcode"><i class="fa-solid fa-user"></i>
                                    </div>
                                </div>
                                <div class="holder">
                                    <div class="informations">
                                        <span>confirm password</span><br>
                                        <input type="password" placeholder="Retype your password as previously typed" required name="retype_passcode"><i class="fa-solid fa-user"></i>
                                    </div>
                                </div>
                                <div class="signupbutton">
                                        <button name="verify_my_Account">create my accunt</button>
                                </div>
                            
                            </form>

                        </div>
                    </div>
                </center>


            </div>
        </div>

        



        <!-- end of mobile screen -->

    </div>
    




    <script>
        setTimeout(function(){
            document.getElementById("dp").style.display = "none";
            document.getElementById("title").style.display = "block";
        },3000);

        $(()=>{
            $("#click_button").click(function(){
                $("#veri_page").slideDown();
            })
        })
    </script>
</body>
</html>