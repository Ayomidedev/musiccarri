







$(()=>{



    $("#live_matche").click(function(){
        $("#live_matche_view").slideDown();
        $("#predicted_games").slideUp();
        $("#upcoming_games").slideUp();
    })



    $("#predicted_matches").click(function(){
        $("#live_matche_view").slideUp();
        $("#predicted_games").slideDown();
        $("#upcoming_games").slideUp();
    })


    $("#upcomign_games").click(function(){
        $("#live_matche_view").slideUp();
        $("#predicted_games").slideUp();
        $("#upcoming_games").slideDown();
    })




// .. break

    $("#live_matche_america").click(function(){
        $("#live_matche_view_america").slideDown();
        $("#predicted_american_games").slideUp();
        $("#upcoming_games").slideUp();
    })



    $("#predicted_matches_america").click(function(){
        $("#live_matche_view_america").slideUp();
        $("#predicted_american_games").slideDown();
        $("#upcoming_games").slideUp();
    })


    $("#upcomig_america").click(function(){
        $("#live_matche_view_america").slideUp();
        $("#predicted_american_games").slideUp();
        $("#upcoming_games_america").slideDown();
    })
































    // $("#upload_football").click(function(){
    //     $("#upload_basketball").slideUp();
    //     $("#upload_football_view").slideDown();
    // })


    
    // $("#uplaod_basketball").click(function(){
    //     $("#upload_basketball").slideDown();
    //     $("#upload_football_view").slideUp();
    // })






})
