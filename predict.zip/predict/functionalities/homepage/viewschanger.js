
function show_selection(){
    document.getElementById("selected_game").style.display = "block";
}

function close_selecte(){
    document.getElementById("selected_game").style.display = "none";
}










$(()=>{



    $("#create_account").click(function(){
        $("#reg_views").slideDown();

        $("#reg_views").css("z-index", "9");
    })
    $("#icon_dash").click(function(){
        $("#all_page_Reg").slideDown(400);
        $("#reg_views").slideUp();
    })



    // login or signup button
    // the signin button
    $("#signin").click(function(){
        $("#login_title").fadeIn();
        $("#signup_title").fadeOut();

        // the views
        $("#login").slideDown();
        $("#signup").slideUp();
    })



    // signup button
    $("#create_account_instead").click(function(){
        $("#login_title").fadeOut();
        $("#signup_title").fadeIn();


        // the views
        $("#login").slideUp();
        $("#signup").slideDown();
    })












    // blinking of the finished game icon

    // default state
    // setInterval(function(){
    //     $("#blinkIcon").fadeIn();
    // }, 100)
    // // change state
    // setInterval(function(){
    //     $("#blinkIcon").fadeOut();
    // }, 100)







    // ... top menus
    $("#menu_oner").click(function(){
        $("#menu_oner").css("border-bottom", "3px solid red");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");


        // showing and hiding of pages
        $("#aboutus").fadeOut();
        $("#pricing_area").fadeOut();


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");
    })

    $("#menu_twor").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })

    $("#menu_threer").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "3px solid red");
        $("#menu_fourr").css("border-bottom", "none");


        $("#aboutus").fadeOut();
        $("#pricing_area").fadeIn();
        $("#aboutus").css('z-index', '5');
        $("#pricing_area").css('z-index', '6');

        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");


    })


    $("#menu_fourr").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "3px solid red");


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");
    })
})