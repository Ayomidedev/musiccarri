


$(()=>{




    $("#live_button").click(function(){

        $("#live_title").slideDown();
        $("#live_matached").slideDown();

        $("#upcoming_title").slideUp();
        $("#upcoming_games").slideUp();

    })


    $("#upcoming_button").click(function(){
        
        $("#live_title").slideUp();
        $("#live_matached").slideUp();


        $("#upcoming_title").slideDown();
        $("#upcoming_games").slideDown();
    })


    $("#predict_Desktop").click(function(){
        alert("create an account to view")
    })



    $("#Tab1").click(function(){
        $("#american_football_views").slideUp();
        $("#football_life_view").slideDown();
    })
    $("#Tab2").click(function(){
        $("#american_football_views").slideDown();
        $("#football_life_view").slideUp();
    })




    $("#live_button_2").click(function(){

        $("#live_title_2").slideDown();
        $("#live_matached_2").slideDown();

        $("#upcoming_title_2").slideUp();
        $("#upcoming_american_games").slideUp();

    })


    $("#upcoming_button_2").click(function(){
        
        $("#live_title_2").slideUp();
        $("#live_matached_2").slideUp();


        $("#upcoming_title_2").slideDown();
        $("#upcoming_american_games").slideDown();
    })




























    $("#live_button_3").click(function(){
        $("#predicted_title").slideDown();
        $("#predicted_match_3").slideDown();

        $("#live_match_title").slideUp();
        $("#live_matached_3").slideUp();


        $("#upcomign_ball_4").slideUp();
        $("#upcoming_american_games_4").slideUp();

    })  

    
    $("#upcoming_button_3").click(function(){

        $("#predicted_title").slideUp();
        $("#predicted_match_3").slideUp();

        $("#live_match_title").slideDown();
        $("#live_matached_3").slideDown();

        
    })

    
    $("#predict_Desktop_3").click(function(){
        $("#predicted_title").slideUp();
        $("#predicted_match_3").slideUp();

        $("#live_match_title").slideUp();
        $("#live_matached_3").slideUp();


        $("#upcomign_ball_4").slideDown();
        $("#upcoming_american_games_4").slideDown();
        
    })























    $("#Tab3").click(function(){
        $("#america_football_da").slideUp();
        $("#fooball_views_da").slideDown();
    })
    $("#Tab4").click(function(){
        $("#america_football_da").slideDown();
        $("#fooball_views_da").slideUp();
    })




    

    $("#live_button_4").click(function(){
        $("#predicted_title_am").slideDown();
        $("#predicted_match_4").slideDown();

        $("#live_match_titles").slideUp();
        $("#live_matached_4").slideUp();


        $("#upcomign_ball_5").slideUp();
        $("#upcoming_american_games_5").slideUp();

    })  

    
    $("#upcoming_button_4").click(function(){

        $("#predicted_title_am").slideUp();
        $("#predicted_match_4").slideUp();

        $("#live_match_titles").slideDown();
        $("#live_matached_4").slideDown();

        $("#upcomign_ball_5").slideUp();
        $("#upcoming_american_games_5").slideUp();

        
    })

    
    $("#predict_Desktop_4").click(function(){
        $("#predicted_title_am").slideUp();
        $("#predicted_match_4").slideUp();

        $("#live_match_titles").slideUp();
        $("#live_matached_4").slideUp();


        $("#upcomign_ball_5").slideDown();
        $("#upcoming_american_games_5").slideDown();
        
    })






































































    // opening menus
    $("#learn_hot_to").click(function(){
        $("#learns").fadeIn();
    })

    $("#learn_hot_to_2").click(function(){
        $("#learns").fadeIn();
    })

    $("#close_learns").click(function(){
        $("#learns").fadeOut();
    })









    $("#pricing_one").click(function(){
        $("#price").fadeIn();
    })
    $("#close_price").click(function(){
        $("#price").fadeOut();
    })
    $("#pricing_two").click(function(){
        $("#price").fadeIn();
    })





    $("#about_d_us").click(function(){
        $("#about_company").fadeIn();
    })
    $("#close__about").click(function(){
        $("#about_company").fadeOut();
    })
    $("#about_d_two").click(function(){
        $("#about_company").fadeIn();
    })
    $("#about_d_three").click(function(){
        $("#about_company").fadeIn();
    })
    $("#about_5_three").click(function(){
        $("#about_company").fadeIn();
    })






    $("#send_feedback_D").click(function(){
        $("#send_feedbacls").fadeIn();
    })

    $("#close__feedback").click(function(){
        $("#send_feedbacls").fadeOut();
    })
    

    $("#send_feedback_D_2").click(function(){
        $("#send_feedbacls").fadeIn();
    })





    
    $("#contact_bb_1").click(function(){
        $("#contadjd").fadeIn();
    })

    $("#close__contactk").click(function(){
        $("#send_feedbacls").fadeOut();
    })
    

    $("#contact_bb_2").click(function(){
        $("#contadjd").fadeIn();
    })








})