


       


        function openabout_us(){
            document.getElementById("contactus").style.display = "block";
            document.getElementById("contactus").style.zIndex = "15";
        }


        function terms_of_user(){
            document.getElementById("terms_of_user").style.display = "block";
            document.getElementById("terms_of_user").style.zIndex = "15";
        }


        function sendfeedback(){
            document.getElementById("sendfeedback").style.display = "block";
            document.getElementById("sendfeedback").style.zIndex = "15";
        }




$(()=>{


        $("#butsr").click(function(){

            $("#butsr").css("background-color", "red");
            $("#butssr").css("background-color", "rgb(14, 14, 36)");
            $("#butsssr").css("background-color", "rgb(14, 14, 36)");
            $("#butssssr").css("background-color", "rgb(14, 14, 36)");



            $("#upcoming_matches").slideUp();
            $("#finished_games").slideDown();
            $("#learn_how_to").slideUp();
        })


        $("#butssr").click(function(){
            $("#butsr").css("background-color", "rgb(14, 14, 36)");
            $("#butssr").css("background-color", "red");
            $("#butsssr").css("background-color", "rgb(14, 14, 36)");
            $("#butssssr").css("background-color", "rgb(14, 14, 36)");


            $("#upcoming_matches").slideDown();
            $("#finished_games").slideUp();
            $("#learn_how_to").slideUp();
        })

        $("#butsssr").click(function(){
            $("#butsr").css("background-color", "rgb(14, 14, 36)");
            $("#butssr").css("background-color", "rgb(14, 14, 36)");
            $("#butsssr").css("background-color", "red");
            $("#butssssr").css("background-color", "rgb(14, 14, 36)");

            $("#upcoming_matches").slideUp();
            $("#finished_games").slideUp();
            $("#learn_how_to").slideDown();
        })


        $("#butssssr").click(function(){
            $("#butsr").css("background-color", "rgb(14, 14, 36)");
            $("#butssr").css("background-color", "rgb(14, 14, 36)");
            $("#butsssr").css("background-color", "rgb(14, 14, 36)");
            $("#butssssr").css("background-color", "red");
        })
















        // contact us closing area
        $("#contactus").click(function(){
            $("#contactus").fadeOut();
        })



        $("#close_terms").click(function(){
            $("#terms_of_user").fadeOut();
        })







        // for footer

        $("#about_us_one").click(function(){

            $("#menu_oner").css("border-bottom", "none");
            $("#menu_twor").css("border-bottom", "3px solid red");
            $("#menu_threer").css("border-bottom", "none");
            $("#menu_fourr").css("border-bottom", "none");
    
            $("#aboutus").fadeIn();
            $("#pricing_area").fadeOut();
            $("#aboutus").css('z-index', '6');
            $("#pricing_area").css('z-index', '5');
    
    
            $("#reg_views").slideUp();
            $("#reg_views").css("z-index", "4");
    
        })





        $("#aboutus_two").click(function(){

            $("#menu_oner").css("border-bottom", "none");
            $("#menu_twor").css("border-bottom", "3px solid red");
            $("#menu_threer").css("border-bottom", "none");
            $("#menu_fourr").css("border-bottom", "none");
    
            $("#aboutus").fadeIn();
            $("#pricing_area").fadeOut();
            $("#aboutus").css('z-index', '6');
            $("#pricing_area").css('z-index', '5');
    
    
            $("#reg_views").slideUp();
            $("#reg_views").css("z-index", "4");

        })




        $("#about_us_three").click(function(){

            $("#menu_oner").css("border-bottom", "none");
            $("#menu_twor").css("border-bottom", "3px solid red");
            $("#menu_threer").css("border-bottom", "none");
            $("#menu_fourr").css("border-bottom", "none");
    
            $("#aboutus").fadeIn();
            $("#pricing_area").fadeOut();
            $("#aboutus").css('z-index', '6');
            $("#pricing_area").css('z-index', '5');
    
    
            $("#reg_views").slideUp();
            $("#reg_views").css("z-index", "4");

        })



        $("#about_us_four").click(function(){

            $("#menu_oner").css("border-bottom", "none");
            $("#menu_twor").css("border-bottom", "3px solid red");
            $("#menu_threer").css("border-bottom", "none");
            $("#menu_fourr").css("border-bottom", "none");
    
            $("#aboutus").fadeIn();
            $("#pricing_area").fadeOut();
            $("#aboutus").css('z-index', '6');
            $("#pricing_area").css('z-index', '5');
    
    
            $("#reg_views").slideUp();
            $("#reg_views").css("z-index", "4");

        })




        // feedbacks
        $("#closebtn").click(function(){
            $("#sendfeedback").fadeOut();
        })







































        // header Bar
        $("#open_drop_show").click(function(){
            $("#drop_bnt").slideDown();
        })


        $("#close_bnt").click(function(){
            $("#drop_bnt").slideUp();
        })


        $("#menu_fourr").click(function(){
            $("#drop_bnt").slideDown();
        })




































        // switching heads
        $("#america_football").click(function(){
            $("#america_footer_view").slideDown();
            $("#football_views").slideUp();
            $("#drop_bnt").slideUp();
        })


        $("#football").click(function(){
            $("#football_views").slideDown();
            $("#america_footer_view").slideUp();
            $("#drop_bnt").slideUp();
        })








        $("#butsrs").click(function(){

            $("#butsrs").css("background-color", "red");
            $("#butssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssssrs").css("background-color", "rgb(14, 14, 36)");


            $("#live_matchaed").slideDown();
            $("#upcoming_america_football").slideUp();
            $("#learn_america").slideUp();


        })


        $("#butssrs").click(function(){

            $("#butsrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssrs").css("background-color", "red");
            $("#butssssrs").css("background-color", "rgb(14, 14, 36)");

            $("#live_matchaed").slideUp();
            $("#upcoming_america_football").slideDown();
            $("#learn_america").slideUp();

            
        })


        $("#butssssrs").click(function(){
            
            $("#butsrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssssrs").css("background-color", "red");


            $("#live_matchaed").slideUp();
            $("#upcoming_america_football").slideUp();
            $("#learn_america").slideDown();


        })











})