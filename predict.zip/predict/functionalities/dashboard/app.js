


        function openabout_us(){
            document.getElementById("contactus").style.display = "block";
            document.getElementById("contactus").style.zIndex = "15";
        }


        function terms_of_user(){
            document.getElementById("terms_of_user").style.display = "block";
            document.getElementById("terms_of_user").style.zIndex = "15";
        }


        function sendfeedback(){
            document.getElementById("sendfeedback").style.display = "block";
            document.getElementById("sendfeedback").style.zIndex = "15";
        }


function show_selection(){
    document.getElementById("selected_game").style.display = "block";
}

function close_selecte(){
    document.getElementById("selected_game").style.display = "none";
}


$(()=>{
    $("#open_drop_show").click(function(){
        $("#drop_btn").fadeIn();
    })

    $("#drop_btn").click(function(){
        $("#drop_btn").fadeOut();
    })





    // tab switching
    $("#butsr").click(function(){
        $("#today_games").slideDown();
        $("#for_fiished_game_areas").slideUp();
        $("#upcoming_matches").slideUp();


        $("#butsr").css("background-color", "red");
        $("#butssr").css("background-color", "rgb(14, 14, 36)");
        $("#butsssr").css("background-color", "rgb(14, 14, 36)");
    })


    $("#butssr").click(function(){
        $("#today_games").slideUp();
        $("#for_fiished_game_areas").slideDown();
        $("#upcoming_matches").slideUp();
        
        
        $("#butssr").css("background-color", "red");
        $("#butsr").css("background-color", "rgb(14, 14, 36)");
        $("#butsssr").css("background-color", "rgb(14, 14, 36)");
    })



    $("#butsssr").click(function(){
        $("#today_games").slideUp();
        $("#for_fiished_game_areas").slideUp();
        $("#upcoming_matches").slideDown();

        $("#butsssr").css("background-color", "red");
        $("#butssr").css("background-color", "rgb(14, 14, 36)");
        $("#butsr").css("background-color", "rgb(14, 14, 36)");

    })

































    


    // ... top menus
    $("#menu_oner").click(function(){
        $("#menu_oner").css("border-bottom", "3px solid red");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");


        // showing and hiding of pages
        $("#aboutus").fadeOut();
        $("#pricing_area").fadeOut();


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");
    })

    $("#menu_twor").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })

    $("#menu_threer").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "3px solid red");
        $("#menu_fourr").css("border-bottom", "none");


        $("#aboutus").fadeOut();
        $("#pricing_area").fadeIn();
        $("#aboutus").css('z-index', '5');
        $("#pricing_area").css('z-index', '6');

        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");


    })


    $("#menu_fourr").click(function(){
        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "none");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "3px solid red");


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");
    })




































     // contact us closing area
     $("#contactus").click(function(){
        $("#contactus").fadeOut();
    })



    $("#close_terms").click(function(){
        $("#terms_of_user").fadeOut();
    })







    // for footer

    $("#about_us_one").click(function(){

        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })





    $("#aboutus_two").click(function(){

        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })




    $("#about_us_three").click(function(){

        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })



    $("#about_us_four").click(function(){

        $("#menu_oner").css("border-bottom", "none");
        $("#menu_twor").css("border-bottom", "3px solid red");
        $("#menu_threer").css("border-bottom", "none");
        $("#menu_fourr").css("border-bottom", "none");

        $("#aboutus").fadeIn();
        $("#pricing_area").fadeOut();
        $("#aboutus").css('z-index', '6');
        $("#pricing_area").css('z-index', '5');


        $("#reg_views").slideUp();
        $("#reg_views").css("z-index", "4");

    })




    // feedbacks
    $("#closebtn").click(function(){
        $("#sendfeedback").fadeOut();
    })







    
        // header Bar
        // $("#open_drop_show").click(function(){
        //     $("#drop_bnt").slideDown();
        // })


        $("#close_bnt").click(function(){
            $("#drop_bnt").slideUp();
        })


        $("#menu_fourr").click(function(){
            $("#drop_bnt").slideDown();
        })




        
        // switching heads
        $("#america_football").click(function(){
            $("#america_footer_view").slideDown();
            $("#football_s").slideUp();
            $("#drop_bnt").slideUp();
        })


        $("#football").click(function(){
            $("#football_s").slideDown();
            $("#america_footer_view").slideUp();
            $("#drop_bnt").slideUp();
        })









        
        $("#butsrs").click(function(){

            $("#butsrs").css("background-color", "red");
            $("#butssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butsssrs").css("background-color", "rgb(14, 14, 36)");


            $("#live_matchaed").slideDown();
            $("#upcoming_america_football").slideUp();
            $("#learn_america").slideUp();
            $("#predicted_matches").slideUp();


        })


        $("#butssrs").click(function(){

            $("#butsrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssrs").css("background-color", "red");
            $("#butsssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssssrs").css("background-color", "rgb(14, 14, 36)");

            $("#live_matchaed").slideUp();
            $("#upcoming_america_football").slideDown();
            $("#learn_america").slideUp();
            $("#predicted_matches").slideUp();

            
        })




        $("#butsssrs").click(function(){

            $("#butsrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssrs").css("background-color", "rgb(14, 14, 36)");;
            $("#butsssrs").css("background-color", "red");
            $("#butssssrs").css("background-color", "rgb(14, 14, 36)");

            $("#live_matchaed").slideUp();
            $("#upcoming_america_football").slideUp();
            $("#learn_america").slideUp();
            $("#predicted_matches").slideDown();

            
        })




        $("#butssssrs").click(function(){
            
            $("#butsrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butsssrs").css("background-color", "rgb(14, 14, 36)");
            $("#butssssrs").css("background-color", "red");


            $("#live_matchaed").slideUp();
            $("#upcoming_america_football").slideUp();
            $("#learn_america").slideDown();
            $("#predicted_matches").slideUp();


        })





})